package com.example

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleAppTest {
    @Test
    fun testAppIdentity() {
        assertEquals("Zahra", "Zahra")
    }
}
