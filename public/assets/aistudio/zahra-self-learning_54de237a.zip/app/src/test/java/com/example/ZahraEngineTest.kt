package com.example

import com.example.data.curriculum.AlphabetPhonicsData
import com.example.data.curriculum.GrammarData
import com.example.data.curriculum.VocabularyData
import com.example.data.model.LearningLevel
import com.example.engine.PronunciationEvaluator
import com.example.engine.TeacherZahraEngine
import com.example.localization.Language
import com.example.localization.Strings
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ZahraEngineTest {

    @Test
    fun testAlphabetCompleteness() {
        // Must contain all 26 English letters from A to Z
        assertEquals(26, AlphabetPhonicsData.letters.size)
        val vowels = AlphabetPhonicsData.letters.filter { it.isVowel }
        assertEquals(5, vowels.size) // A, E, I, O, U
    }

    @Test
    fun testCurriculumLevelsSpanA0ToPostC2() {
        val levels = LearningLevel.entries
        assertTrue(levels.any { it == LearningLevel.A0 })
        assertTrue(levels.any { it == LearningLevel.C2 })
        assertTrue(levels.any { it == LearningLevel.POST_C2 })
    }

    @Test
    fun testPronunciationEvaluationExactMatch() {
        val expected = "Apple"
        val result = PronunciationEvaluator.evaluate(expected, "Apple")
        assertEquals(100, result.score)
        assertTrue(result.accuracy.contains("Excellent") || result.score >= 90)
    }

    @Test
    fun testPronunciationEvaluationLevenshteinDistance() {
        val expected = "Beautiful flower"
        val closeSpoken = "Beutiful flower"
        val result = PronunciationEvaluator.evaluate(expected, closeSpoken)
        assertTrue(result.score in 70..99)
    }

    @Test
    fun testTeacherWritingCorrection() {
        val input = "i am agree with zahra. he go to school"
        val correction = TeacherZahraEngine.analyzeWriting(input)
        assertTrue(correction.issuesFound.isNotEmpty())
        assertTrue(correction.correctedText.contains("I agree"))
        assertTrue(correction.correctedText.contains("goes"))
    }

    @Test
    fun testThreeLanguagesTranslationsNonEmpty() {
        for (lang in Language.entries) {
            val title = Strings.appTitle(lang)
            val teacherName = Strings.teacherName(lang)
            val quote = Strings.teacherWelcomeQuote(lang)
            val reminder = Strings.reminderVoiceMessage(lang)

            assertTrue("Title should not be empty for $lang", title.isNotBlank())
            assertTrue("Teacher name should not be empty for $lang", teacherName.isNotBlank())
            assertTrue("Quote should not be empty for $lang", quote.isNotBlank())
            assertTrue("Reminder should not be empty for $lang", reminder.isNotBlank())
        }
    }

    @Test
    fun testVocabularyHasTranslationsInDariAndPashto() {
        val sampleWord = VocabularyData.words.first()
        assertTrue(sampleWord.defDari.isNotBlank())
        assertTrue(sampleWord.defPashto.isNotBlank())
        assertTrue(sampleWord.exampleDari.isNotBlank())
        assertTrue(sampleWord.examplePashto.isNotBlank())
    }

    @Test
    fun testGrammarLessonsHaveQuizzes() {
        val lesson = GrammarData.lessons.first()
        assertTrue(lesson.quiz.isNotEmpty())
        val q = lesson.quiz.first()
        assertTrue(q.options.isNotEmpty())
        assertTrue(q.correctIndex in 0 until q.options.size)
    }
}
