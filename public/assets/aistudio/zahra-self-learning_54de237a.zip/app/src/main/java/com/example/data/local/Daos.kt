package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getUserProfile(): Flow<UserProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(profile: UserProfileEntity)
}

@Dao
interface ScheduleDao {
    @Query("SELECT * FROM study_schedules ORDER BY hour ASC, minute ASC")
    fun getAllSchedules(): Flow<List<ScheduleEntity>>

    @Query("SELECT * FROM study_schedules WHERE isEnabled = 1")
    suspend fun getActiveSchedulesList(): List<ScheduleEntity>

    @Query("SELECT * FROM study_schedules WHERE id = :id LIMIT 1")
    suspend fun getScheduleById(id: Long): ScheduleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(schedule: ScheduleEntity): Long

    @Update
    suspend fun update(schedule: ScheduleEntity)

    @Query("DELETE FROM study_schedules WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface VocabDao {
    @Query("SELECT * FROM vocab_progress")
    fun getAllProgress(): Flow<List<VocabProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(progress: VocabProgressEntity)

    @Query("SELECT COUNT(*) FROM vocab_progress WHERE srsBox >= 3")
    fun getMasteredWordsCount(): Flow<Int>
}

@Dao
interface MistakeDao {
    @Query("SELECT * FROM mistakes_history ORDER BY timestamp DESC")
    fun getAllMistakes(): Flow<List<MistakeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(mistake: MistakeEntity)

    @Query("DELETE FROM mistakes_history")
    suspend fun clearAll()
}

@Dao
interface AssessmentDao {
    @Query("SELECT * FROM assessment_records ORDER BY timestamp DESC LIMIT 1")
    fun getLatestAssessment(): Flow<AssessmentEntity?>

    @Query("SELECT * FROM assessment_records ORDER BY timestamp DESC")
    fun getAllAssessments(): Flow<List<AssessmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(assessment: AssessmentEntity)
}
