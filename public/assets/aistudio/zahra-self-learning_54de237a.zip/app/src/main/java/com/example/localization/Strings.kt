package com.example.localization

object Strings {
    fun appTitle(lang: Language): String = when (lang) {
        Language.DARI -> "خودسازی زهرا"
        Language.PASHTO -> "د زهرا ځان جوړونه"
        Language.ENGLISH -> "Zahra Self Learning"
    }

    fun appSubtitle(lang: Language): String = when (lang) {
        Language.DARI -> "آکادمی هوشمند و کاملاً آفلاین آموزش زبان انگلیسی"
        Language.PASHTO -> "د انګلیسي ژبې هوښیاره او بشپړه آفلاین اکاډمي"
        Language.ENGLISH -> "Smart & Completely Offline English Learning Academy"
    }

    fun teacherName(lang: Language): String = when (lang) {
        Language.DARI -> "استاد گوهری"
        Language.PASHTO -> "استاده ګوهري"
        Language.ENGLISH -> "Teacher Gohari"
    }

    fun teacherRole(lang: Language): String = when (lang) {
        Language.DARI -> "معلم خصوصی هوشمند شما"
        Language.PASHTO -> "ستاسو هوښیاره خصوصي استاده"
        Language.ENGLISH -> "Your Smart Personal AI Tutor"
    }

    // Navigation Tabs
    fun navDashboard(lang: Language): String = when (lang) {
        Language.DARI -> "داشبورد"
        Language.PASHTO -> "ډشبورډ"
        Language.ENGLISH -> "Dashboard"
    }

    fun navTeacher(lang: Language): String = when (lang) {
        Language.DARI -> "استاد گوهری"
        Language.PASHTO -> "استاده ګوهري"
        Language.ENGLISH -> "Teacher Gohari"
    }

    fun navPath(lang: Language): String = when (lang) {
        Language.DARI -> "مسیر یادگیری"
        Language.PASHTO -> "د زده کړې لار"
        Language.ENGLISH -> "Curriculum"
    }

    fun navPractice(lang: Language): String = when (lang) {
        Language.DARI -> "مهارت‌ها"
        Language.PASHTO -> "مهارتونه"
        Language.ENGLISH -> "Skills"
    }

    fun navSchedule(lang: Language): String = when (lang) {
        Language.DARI -> "زمان‌بندی"
        Language.PASHTO -> "وخت ویش"
        Language.ENGLISH -> "Schedule"
    }

    fun navSettings(lang: Language): String = when (lang) {
        Language.DARI -> "تنظیمات"
        Language.PASHTO -> "ترتیبات"
        Language.ENGLISH -> "Settings"
    }

    // Dashboard Items
    fun welcomeBack(lang: Language, name: String): String = when (lang) {
        Language.DARI -> "سلام $name عزیز! خوش آمدید"
        Language.PASHTO -> "سلام ګرانې $name! ښه راغلاست"
        Language.ENGLISH -> "Welcome back, $name!"
    }

    fun teacherWelcomeQuote(lang: Language): String = when (lang) {
        Language.DARI -> "«یادگیری یک سفر زیباست. گام به گام و با تمرین روزانه، تو به قله‌های تسلط به زبان انگلیسی خواهی رسید. من همیشه در کنارت هستم.»"
        Language.PASHTO -> "«زده کړه یو ښکلی سفر دی. ګام په ګام او په ورځني تمرین سره، ته به د انګلیسي ژبې په تسلط کې لوړو پوړونو ته ورسیږې. زه تل درسره یم.»"
        Language.ENGLISH -> "“Learning is a noble journey. Step by step with steady daily practice, you will master English. I am right beside you.”"
    }

    fun currentLevelLabel(lang: Language): String = when (lang) {
        Language.DARI -> "سطح فعلی شما"
        Language.PASHTO -> "ستاسو اوسنۍ کچه"
        Language.ENGLISH -> "Current Level"
    }

    fun nextGoalLabel(lang: Language): String = when (lang) {
        Language.DARI -> "هدف بعدی"
        Language.PASHTO -> "بل هدف"
        Language.ENGLISH -> "Next Goal"
    }

    fun streakDaysLabel(lang: Language): String = when (lang) {
        Language.DARI -> "روزهای متوالی"
        Language.PASHTO -> "پرله پسې ورځې"
        Language.ENGLISH -> "Daily Streak"
    }

    fun studyMinutesLabel(lang: Language): String = when (lang) {
        Language.DARI -> "دقایق مطالعه"
        Language.PASHTO -> "د مطالعې دقیقې"
        Language.ENGLISH -> "Study Minutes"
    }

    fun wordsLearnedLabel(lang: Language): String = when (lang) {
        Language.DARI -> "لغات یادگرفته"
        Language.PASHTO -> "زده شوي لغتونه"
        Language.ENGLISH -> "Words Mastered"
    }

    fun offlineStatus(lang: Language): String = when (lang) {
        Language.DARI -> "۱۰۰٪ آفلاین • بدون نیاز به اینترنت"
        Language.PASHTO -> "۱۰۰٪ آفلاین • انټرنیټ ته اړتیا نشته"
        Language.ENGLISH -> "100% Offline • No Internet Required"
    }

    // Common Buttons
    fun btnStart(lang: Language): String = when (lang) {
        Language.DARI -> "شروع درس"
        Language.PASHTO -> "درس پیل کړئ"
        Language.ENGLISH -> "Start Lesson"
    }

    fun btnContinue(lang: Language): String = when (lang) {
        Language.DARI -> "ادامه دادن"
        Language.PASHTO -> "دوام ورکړئ"
        Language.ENGLISH -> "Continue"
    }

    fun btnListen(lang: Language): String = when (lang) {
        Language.DARI -> "شنیدن تلفظ"
        Language.PASHTO -> "تلفظ واورئ"
        Language.ENGLISH -> "Listen Audio"
    }

    fun btnSlowListen(lang: Language): String = when (lang) {
        Language.DARI -> "شنیدن آهسته"
        Language.PASHTO -> "ورو اوریدل"
        Language.ENGLISH -> "Listen Slow"
    }

    fun btnRecord(lang: Language): String = when (lang) {
        Language.DARI -> "تکرار و ضبط صدا"
        Language.PASHTO -> "تکرار او غږ ثبتول"
        Language.ENGLISH -> "Record & Speak"
    }

    fun btnSubmit(lang: Language): String = when (lang) {
        Language.DARI -> "ارزیابی و بررسی"
        Language.PASHTO -> "ارزونه او کره کتل"
        Language.ENGLISH -> "Evaluate"
    }

    fun btnSave(lang: Language): String = when (lang) {
        Language.DARI -> "ذخیره کردن"
        Language.PASHTO -> "خوندي کول"
        Language.ENGLISH -> "Save"
    }

    fun btnCancel(lang: Language): String = when (lang) {
        Language.DARI -> "انصراف"
        Language.PASHTO -> "لغوه"
        Language.ENGLISH -> "Cancel"
    }

    fun btnNext(lang: Language): String = when (lang) {
        Language.DARI -> "بعدی"
        Language.PASHTO -> "بل"
        Language.ENGLISH -> "Next"
    }

    fun btnPrevious(lang: Language): String = when (lang) {
        Language.DARI -> "قبلی"
        Language.PASHTO -> "مخکینی"
        Language.ENGLISH -> "Previous"
    }

    // Sections
    fun sectionAlphabetPhonics(lang: Language): String = when (lang) {
        Language.DARI -> "الفبا و آواشناسی (Phonics)"
        Language.PASHTO -> "الفبا او اواز پوهنه (Phonics)"
        Language.ENGLISH -> "Alphabet & Phonics"
    }

    fun sectionVocabulary(lang: Language): String = when (lang) {
        Language.DARI -> "دایره لغات (Vocabulary)"
        Language.PASHTO -> "د لغتونو خزانه (Vocabulary)"
        Language.ENGLISH -> "Vocabulary & SRS"
    }

    fun sectionGrammar(lang: Language): String = when (lang) {
        Language.DARI -> "دستور زبان (Grammar)"
        Language.PASHTO -> "ګرامر او اصول (Grammar)"
        Language.ENGLISH -> "Grammar Academy"
    }

    fun sectionConversation(lang: Language): String = when (lang) {
        Language.DARI -> "مکالمه زنده با استاد گوهری"
        Language.PASHTO -> "له استاده ګوهري سره ژوندی خبرې اترې"
        Language.ENGLISH -> "Live Conversation with Teacher Gohari"
    }

    fun sectionReadingStories(lang: Language): String = when (lang) {
        Language.DARI -> "کتابخانه داستان‌ها و متون"
        Language.PASHTO -> "د کیسو او متنونو کتابتون"
        Language.ENGLISH -> "Stories & Reading Library"
    }

    fun sectionWritingLab(lang: Language): String = when (lang) {
        Language.DARI -> "کارگاه نگارش و ویرایش"
        Language.PASHTO -> "د لیکلو او سمولو کارځای"
        Language.ENGLISH -> "Writing & Correction Lab"
    }

    fun sectionAssessment(lang: Language): String = when (lang) {
        Language.DARI -> "آزمون‌ها و ارزیابی جامع"
        Language.PASHTO -> "ازموینې او هر اړخیزه ارزونه"
        Language.ENGLISH -> "Tests & Comprehensive Assessment"
    }

    fun sectionDailySchedule(lang: Language): String = when (lang) {
        Language.DARI -> "زمان‌بندی و زنگ یادآوری صوتی"
        Language.PASHTO -> "د وخت ویش او غږیز یادښت"
        Language.ENGLISH -> "Daily Schedule & Voice Alarm"
    }

    fun sectionHomework(lang: Language): String = when (lang) {
        Language.DARI -> "تکالیف شخصی استاد گوهری"
        Language.PASHTO -> "د استاده ګوهري ځانګړي کورني کارونه"
        Language.ENGLISH -> "Teacher Gohari's Assignments"
    }

    // Voice Reminder Text
    fun reminderVoiceMessage(lang: Language): String = when (lang) {
        Language.DARI -> "سلام عزیزم! من استاد گوهری هستم. وقت یادگیری انگلیسی رسیده. بیا امروز هم یک قدم به هدفت نزدیکتر شویم."
        Language.PASHTO -> "سلام ګرانې! زه استاده ګوهري یم. د انګلیسي زده کړې وخت رارسیدلی. راځه نن هم خپل هدف ته یو ګام نږدې شو."
        Language.ENGLISH -> "Hello dear! I am Teacher Gohari. It's time for your English lesson. Let's take another proud step toward your goal today."
    }

    fun reminderNotificationTitle(lang: Language): String = when (lang) {
        Language.DARI -> "استاد گوهری منتظر شماست!"
        Language.PASHTO -> "استاده ګوهري ستاسو په تمه ده!"
        Language.ENGLISH -> "Teacher Gohari is Waiting for You!"
    }

    fun reminderActionStart(lang: Language): String = when (lang) {
        Language.DARI -> "شروع درس"
        Language.PASHTO -> "درس پیل"
        Language.ENGLISH -> "Start Lesson"
    }

    fun reminderActionSnooze5(lang: Language): String = when (lang) {
        Language.DARI -> "تعویق ۵ دقیقه"
        Language.PASHTO -> "۵ دقیقې وروسته"
        Language.ENGLISH -> "Snooze 5m"
    }

    fun reminderActionSnooze10(lang: Language): String = when (lang) {
        Language.DARI -> "تعویق ۱۰ دقیقه"
        Language.PASHTO -> "۱۰ دقیقې وروسته"
        Language.ENGLISH -> "Snooze 10m"
    }

    fun reminderActionDismiss(lang: Language): String = when (lang) {
        Language.DARI -> "رد کردن"
        Language.PASHTO -> "ردول"
        Language.ENGLISH -> "Dismiss"
    }
}
