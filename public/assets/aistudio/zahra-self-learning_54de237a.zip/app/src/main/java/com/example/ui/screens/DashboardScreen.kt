package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LearningLevel
import com.example.localization.Strings
import com.example.ui.AppScreen
import com.example.ui.MainViewModel
import com.example.ui.components.GoldButton
import com.example.ui.components.PopcornCircleButton
import com.example.ui.components.LevelBadge
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.components.ZahraAvatarView
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val profile by viewModel.userProfile.collectAsState()
    val schedules by viewModel.schedulesList.collectAsState()
    val masteredWords by viewModel.masteredWordsCount.collectAsState()
    val currentLevel = profile?.currentLevelCode?.let { code ->
        LearningLevel.entries.firstOrNull { it.code == code }
    } ?: LearningLevel.A0

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(8.dp)) }

        // Top Hero Card with Teacher Zahra
        item {
            LuxuryGlassCard(
                modifier = Modifier.testTag("hero_zahra_card"),
                borderColor = LuxuryGold
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    ZahraAvatarView(size = 72.dp)

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = Strings.teacherName(lang),
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = LuxuryGold,
                                    fontSize = 20.sp
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            LevelBadge(levelCode = currentLevel.code)
                        }

                        Text(
                            text = Strings.teacherRole(lang),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = Strings.offlineStatus(lang),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = EmeraldGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Teacher Inspiring Quote
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(LuxuryGold.copy(alpha = 0.08f))
                        .border(1.dp, LuxuryGold.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = Strings.teacherWelcomeQuote(lang),
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = SoftGold,
                            fontSize = 13.5.sp,
                            lineHeight = 22.sp
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    GoldButton(
                        text = Strings.btnStart(lang),
                        icon = Icons.Default.PlayArrow,
                        onClick = { viewModel.navigateTo(AppScreen.ALPHABET_PHONICS) },
                        modifier = Modifier.weight(1f),
                        testTag = "btn_start_learning"
                    )

                    PopcornCircleButton(
                        icon = Icons.Default.VolumeUp,
                        contentDescription = "Listen to Teacher Gohari voice",
                        onClick = {
                            viewModel.speak(Strings.reminderVoiceMessage(lang))
                        },
                        size = 52.dp
                    )
                }
            }
        }

        // Live Timetable Card with Next Alarm
        item {
            val nextSchedule = schedules.firstOrNull { it.isEnabled }
            LuxuryGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo(AppScreen.DAILY_SCHEDULE) },
                borderColor = WarmGold.copy(alpha = 0.5f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(WarmGold.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Alarm,
                            contentDescription = null,
                            tint = LuxuryGold,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = Strings.sectionDailySchedule(lang),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        if (nextSchedule != null) {
                            val timeStr = String.format("%02d:%02d", nextSchedule.hour, nextSchedule.minute)
                            Text(
                                text = "Next Alarm: $timeStr • ${nextSchedule.titleEn}",
                                style = MaterialTheme.typography.bodySmall.copy(color = SoftGold)
                            )
                        } else {
                            Text(
                                text = "All alarms active • Tap to manage timetable",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = "Test voice alarm",
                        tint = LuxuryGold,
                        modifier = Modifier
                            .size(28.dp)
                            .clickable { viewModel.testAlarmVoiceNow() }
                    )
                }
            }
        }

        // Metric Counters Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricBox(
                    title = Strings.streakDaysLabel(lang),
                    value = "${profile?.streakDays ?: 3} Days",
                    color = LuxuryGold,
                    modifier = Modifier.weight(1f)
                )
                MetricBox(
                    title = Strings.wordsLearnedLabel(lang),
                    value = "$masteredWords Words",
                    color = EmeraldGreen,
                    modifier = Modifier.weight(1f)
                )
                MetricBox(
                    title = Strings.studyMinutesLabel(lang),
                    value = "${profile?.totalStudyMinutes ?: 45} Min",
                    color = ChampagneGold,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Academy Learning Modules Section
        item {
            Text(
                text = Strings.navPath(lang),
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = LuxuryGold
                ),
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Alphabet & Phonics Card
                ModuleRowCard(
                    icon = Icons.Default.FontDownload,
                    title = Strings.sectionAlphabetPhonics(lang),
                    subtitle = "26 Letters • Phonics Sounds • Digraphs & IPA",
                    badge = "A0 Foundation",
                    onClick = { viewModel.navigateTo(AppScreen.ALPHABET_PHONICS) }
                )

                // Conversation with Zahra Card
                ModuleRowCard(
                    icon = Icons.Default.Chat,
                    title = Strings.sectionConversation(lang),
                    subtitle = "Voice & Text Roleplays • Airport, Interview & Daily Life",
                    badge = "AI Tutor",
                    onClick = { viewModel.navigateTo(AppScreen.TEACHER_CHAT) }
                )

                // Vocabulary & SRS Card
                ModuleRowCard(
                    icon = Icons.Default.MenuBook,
                    title = Strings.sectionVocabulary(lang),
                    subtitle = "Spaced Repetition (SRS) • Dari & Pashto Meanings",
                    badge = "A0 - Post-C2",
                    onClick = { viewModel.navigateTo(AppScreen.VOCABULARY_SRS) }
                )

                // Grammar Academy Card
                ModuleRowCard(
                    icon = Icons.Default.School,
                    title = Strings.sectionGrammar(lang),
                    subtitle = "From Verb To Be to Inversion & Subjunctive",
                    badge = "Deep Academy",
                    onClick = { viewModel.navigateTo(AppScreen.GRAMMAR_ACADEMY) }
                )

                // Stories Library Card
                ModuleRowCard(
                    icon = Icons.Default.AutoStories,
                    title = Strings.sectionReadingStories(lang),
                    subtitle = "Graded Readers with Offline Audio Narration",
                    badge = "Reading",
                    onClick = { viewModel.navigateTo(AppScreen.STORIES_LIBRARY) }
                )

                // Writing Lab Card
                ModuleRowCard(
                    icon = Icons.Default.Create,
                    title = Strings.sectionWritingLab(lang),
                    subtitle = "Grammar & Style Engine with Step-by-Step Reasonings",
                    badge = "Writing Lab",
                    onClick = { viewModel.navigateTo(AppScreen.WRITING_LAB) }
                )

                // Assessment & Progress Card
                ModuleRowCard(
                    icon = Icons.Default.Insights,
                    title = Strings.sectionAssessment(lang),
                    subtitle = "Real CEFR Evaluation • 7 Skill Radar Metrics",
                    badge = "Analytics",
                    onClick = { viewModel.navigateTo(AppScreen.ASSESSMENT_REPORT) }
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun MetricBox(
    title: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.3f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 15.sp,
                color = color
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun ModuleRowCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    badge: String,
    onClick: () -> Unit
) {
    val cardShape = RoundedCornerShape(22.dp)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        // Bottom 3D Extrusion Shadow Layer (Popcorn Pop-out Base)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .matchParentSize()
                .offset(y = 4.dp)
                .clip(cardShape)
                .background(com.example.ui.theme.PopcornDarkShadow)
        )

        // Main Puffy Tactile Card
        Card(
            shape = cardShape,
            colors = CardDefaults.cardColors(
                containerColor = com.example.ui.theme.PopcornSurface.copy(alpha = 0.95f)
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                Brush.verticalGradient(
                    listOf(
                        com.example.ui.theme.PopcornBorder.copy(alpha = 0.7f),
                        GlowGold.copy(alpha = 0.3f),
                        DarkBorder
                    )
                )
            ),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onClick() }
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    com.example.ui.theme.PopcornBorder.copy(alpha = 0.25f),
                                    LuxuryGold.copy(alpha = 0.12f)
                                )
                            )
                        )
                        .border(1.dp, com.example.ui.theme.PopcornBorder.copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = com.example.ui.theme.PopcornGold,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 15.sp
                            ),
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        LevelBadge(levelCode = badge)
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 12.sp
                        ),
                        maxLines = 1
                    )
                }
            }
        }
    }
}
