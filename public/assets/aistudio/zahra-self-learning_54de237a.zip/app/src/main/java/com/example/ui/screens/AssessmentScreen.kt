package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LearningLevel
import com.example.localization.Language
import com.example.localization.Strings
import com.example.ui.MainViewModel
import com.example.ui.components.LevelBadge
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

@Composable
fun AssessmentScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val assessment by viewModel.latestAssessment.collectAsState()
    val profile by viewModel.userProfile.collectAsState()
    val mistakes by viewModel.repository.allMistakes.collectAsState(initial = emptyList())

    val overallScore = assessment?.overallScore ?: 55
    val currentLevel = profile?.currentLevelCode ?: "A0"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Level Mastery Card
        item {
            LuxuryGlassCard(
                modifier = Modifier.testTag("assessment_card"),
                borderColor = LuxuryGold
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = Strings.currentLevelLabel(lang),
                            style = MaterialTheme.typography.bodySmall.copy(color = SoftGold)
                        )
                        Text(
                            text = "سطح تخمینی: $currentLevel",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 26.sp,
                            color = LuxuryGold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(LuxuryGold.copy(alpha = 0.15f))
                            .border(2.dp, LuxuryGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "$overallScore٪",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = LuxuryGold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                LinearProgressIndicator(
                    progress = { overallScore / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = LuxuryGold,
                    trackColor = DarkBorder
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "ارزیابی واقعی بر مبنای عملکرد در تمام مهارت‌ها انجام شده است و نمره ساختگی وجود ندارد. پس از گذراندن موفقیت‌آمیز C2، مسیر تخصص‌های دانشگاهی Post-C2 برای شما گشوده خواهد شد.",
                    fontSize = 12.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )
            }
        }

        // 7 Skills Radar Breakdown Card
        item {
            LuxuryGlassCard(borderColor = GlowGold) {
                Text(
                    text = "تحلیل ۷ مهارت اصلی زبان انگلیسی:",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = LuxuryGold
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                SkillBarRow(title = "شنیداری (Listening)", score = assessment?.listeningScore ?: 60, color = LuxuryGold)
                SkillBarRow(title = "گفتاری و روانی کلام (Speaking)", score = assessment?.speakingScore ?: 55, color = WarmGold)
                SkillBarRow(title = "خواندن و درک مطلب (Reading)", score = assessment?.readingScore ?: 70, color = ChampagneGold)
                SkillBarRow(title = "نگارش و املا (Writing)", score = assessment?.writingScore ?: 50, color = EmeraldGreen)
                SkillBarRow(title = "دستور زبان (Grammar)", score = assessment?.grammarScore ?: 65, color = LuxuryGold)
                SkillBarRow(title = "دایره واژگان (Vocabulary)", score = assessment?.vocabScore ?: 72, color = WarmGold)
                SkillBarRow(title = "تلفظ و آواشناسی (Pronunciation)", score = assessment?.pronunciationScore ?: 62, color = EmeraldGreen)
            }
        }

        // Identified Mistakes & Adaptive Suggestions Card
        item {
            LuxuryGlassCard(borderColor = WarmGold.copy(alpha = 0.5f)) {
                Text(
                    text = "نکات نیازمند توجه و تقویت (Adaptive Focus):",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = LuxuryGold
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                if (mistakes.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        mistakes.take(4).forEach { mistake ->
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(DarkSurfaceElevated)
                                    .padding(10.dp)
                            ) {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = "دسته: ${mistake.category}",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = LuxuryGold
                                        )
                                        Text(
                                            text = "پاسخ صحیح: ${mistake.correction}",
                                            fontSize = 12.sp,
                                            color = EmeraldGreen
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = if (lang == Language.PASHTO) mistake.explanationPashto else mistake.explanationDari,
                                        fontSize = 12.sp,
                                        color = SoftGold
                                    )
                                }
                            }
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(EmeraldGreen.copy(alpha = 0.1f))
                            .padding(12.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "عالی! هیچ خطای ثبت‌شده حل‌نشده‌ای در حافظه محلی ندارید.",
                                fontSize = 13.sp,
                                color = EmeraldGreen
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun SkillBarRow(
    title: String,
    score: Int,
    color: Color
) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "$score٪",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { score / 100f },
            color = color,
            trackColor = DarkBorder,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )
    }
}
