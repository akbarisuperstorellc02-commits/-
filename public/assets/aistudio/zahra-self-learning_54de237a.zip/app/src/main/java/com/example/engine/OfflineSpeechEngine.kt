package com.example.engine

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class OfflineSpeechEngine(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private var currentPitch: Float = 1.18f
    private var currentSpeed: Float = 0.95f
    private var isUSAccent: Boolean = true

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("OfflineSpeechEngine", "Error initializing TTS", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            applyVoiceSettings()
        }
    }

    fun setVoiceConfig(pitch: Float, speed: Float, isUS: Boolean) {
        currentPitch = pitch
        currentSpeed = speed
        isUSAccent = isUS
        if (isInitialized) {
            applyVoiceSettings()
        }
    }

    private fun applyVoiceSettings() {
        val engine = tts ?: return
        try {
            val locale = if (isUSAccent) Locale.US else Locale.UK
            engine.language = locale
            engine.setPitch(currentPitch)
            engine.setSpeechRate(currentSpeed)

            // Try to find a female voice
            val voices = engine.voices
            if (voices != null) {
                val femaleVoice = voices.firstOrNull { voice ->
                    val name = voice.name.lowercase(Locale.ROOT)
                    voice.locale.language == locale.language &&
                            (name.contains("female") || name.contains("woman") || name.contains("#female"))
                }
                if (femaleVoice != null) {
                    engine.voice = femaleVoice
                }
            }
        } catch (e: Exception) {
            Log.w("OfflineSpeechEngine", "Could not customize female voice explicitly, using adjusted pitch", e)
        }
    }

    fun speak(text: String, isSlow: Boolean = false, onComplete: (() -> Unit)? = null) {
        if (!isInitialized || tts == null) {
            onComplete?.invoke()
            return
        }
        val rate = if (isSlow) currentSpeed * 0.7f else currentSpeed
        tts?.setSpeechRate(rate)
        tts?.setPitch(currentPitch)
        _isSpeaking.value = true

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utterance_zahra")
        // Reset speech rate back
        tts?.setSpeechRate(currentSpeed)
        _isSpeaking.value = false
        onComplete?.invoke()
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
