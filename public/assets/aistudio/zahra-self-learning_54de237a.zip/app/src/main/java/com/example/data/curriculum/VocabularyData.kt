package com.example.data.curriculum

import com.example.data.model.LearningLevel
import com.example.data.model.VocabularyWord

object VocabularyData {
    val words: List<VocabularyWord> = listOf(
        // A0
        VocabularyWord(
            id = "w_a0_1",
            word = "Hello",
            ipa = "/həˈloʊ/",
            partOfSpeech = "interjection",
            defDari = "سلام، درود",
            defPashto = "سلام، روغبړ",
            defEn = "Used as a greeting when meeting someone",
            exampleEn = "Hello! My name is Zahra.",
            exampleDari = "سلام! نام من زهرا است.",
            examplePashto = "سلام! زما نوم زهرا دی.",
            collocation = "Say hello to someone",
            commonMistake = "Don't confuse with informal 'Hey' in formal meetings.",
            level = LearningLevel.A0
        ),
        VocabularyWord(
            id = "w_a0_2",
            word = "Thank you",
            ipa = "/ˈθæŋk juː/",
            partOfSpeech = "phrase",
            defDari = "تشکر، ممنون شما",
            defPashto = "مننه، منندوی یم",
            defEn = "Polite expression of gratitude",
            exampleEn = "Thank you very much for your kind help.",
            exampleDari = "از کمک مهربانانه شما بسیار تشکر.",
            examplePashto = "ستاسو له مهربانې مرستې ډیره مننه.",
            collocation = "Thank you so much",
            commonMistake = "Say 'Thank you' or 'Thanks', but NOT 'Thanks you'.",
            level = LearningLevel.A0
        ),
        VocabularyWord(
            id = "w_a0_3",
            word = "Water",
            ipa = "/ˈwɔː.tər/",
            partOfSpeech = "noun",
            defDari = "آب",
            defPashto = "اوبه",
            defEn = "A clear liquid essential for all life",
            exampleEn = "May I please have a glass of water?",
            exampleDari = "ممکن است لطفاً یک گیلاس آب داشته باشم؟",
            examplePashto = "ایا زه کولی شم یو ګیلاس اوبه وڅښم؟",
            collocation = "Drink water / Pure water",
            commonMistake = "Water is uncountable; don't say 'two waters' in formal speech.",
            level = LearningLevel.A0
        ),
        VocabularyWord(
            id = "w_a0_4",
            word = "Book",
            ipa = "/bʊk/",
            partOfSpeech = "noun",
            defDari = "کتاب",
            defPashto = "کتاب",
            defEn = "A set of printed or written pages bound together",
            exampleEn = "I read an inspiring English book every evening.",
            exampleDari = "من هر شام یک کتاب الهام‌بخش انگلیسی می‌خوانم.",
            examplePashto = "زه هر ماښام یو الهام بخښونکی انګلیسي کتاب لولم.",
            collocation = "Read a book / Open a book",
            commonMistake = "Pronounced with a short /ʊ/ as in 'look', not long /uː/.",
            level = LearningLevel.A0
        ),

        // Pre-A1 & A1
        VocabularyWord(
            id = "w_a1_1",
            word = "Family",
            ipa = "/ˈfæm.əl.i/",
            partOfSpeech = "noun",
            defDari = "خانواده، فامیل",
            defPashto = "کورنۍ",
            defEn = "A group consisting of parents and children living together",
            exampleEn = "My family always supports my dreams and education.",
            exampleDari = "خانواده من همیشه از آرزوها و آموزش من حمایت می‌کنند.",
            examplePashto = "زما کورنۍ تل زما د هیلو او زده کړې ملاتړ کوي.",
            collocation = "Close family / Big family",
            commonMistake = "Usually singular in American English: 'My family is supportive'.",
            level = LearningLevel.A1
        ),
        VocabularyWord(
            id = "w_a1_2",
            word = "Morning",
            ipa = "/ˈmɔːr.nɪŋ/",
            partOfSpeech = "noun",
            defDari = "صبح، بامداد",
            defPashto = "سهار",
            defEn = "The early part of the day from sunrise to noon",
            exampleEn = "Good morning! Are you ready for today's practice?",
            exampleDari = "صبح بخیر! آیا برای تمرین امروز آماده هستید؟",
            examplePashto = "سهار پخیر! ایا تاسو د نن ورځې تمرین ته چمتو یاست؟",
            collocation = "In the morning / Early morning",
            commonMistake = "Use 'in the morning', not 'at the morning'.",
            level = LearningLevel.A1
        ),

        // A2
        VocabularyWord(
            id = "w_a2_1",
            word = "Journey",
            ipa = "/ˈdʒɜːr.ni/",
            partOfSpeech = "noun",
            defDari = "سفر، مسیر پیموده شده",
            defPashto = "سفر، مزل",
            defEn = "An act of traveling from one place to another",
            exampleEn = "Mastering a language is a wonderful lifetime journey.",
            exampleDari = "تسلط بر یک زبان یک سفر فوق‌العاده تمام‌عمر است.",
            examplePashto = "په یوې ژبې تسلط د ټول ژوند یو حیرانونکی سفر دی.",
            collocation = "Long journey / Start a journey",
            commonMistake = "Journey refers to the traveling process; 'Trip' is the visit itself.",
            level = LearningLevel.A2
        ),

        // B1
        VocabularyWord(
            id = "w_b1_1",
            word = "Confidence",
            ipa = "/ˈkɑːn.fə.dəns/",
            partOfSpeech = "noun",
            defDari = "اعتماد به نفس، اطمینان خاطر",
            defPashto = "پر ځان باور، ډاډ",
            defEn = "The feeling or belief that one can rely on someone or something",
            exampleEn = "Daily speaking practice gives you natural confidence.",
            exampleDari = "تمرین روزانه صحبت کردن به شما اعتماد به نفس طبیعی می‌بخشد.",
            examplePashto = "ورځنۍ خبرې اترې تاسو ته په ځان طبیعي باور درکوي.",
            collocation = "Build confidence / Boost confidence",
            commonMistake = "Adjective is 'Confident', noun is 'Confidence'.",
            level = LearningLevel.B1
        ),

        // B2
        VocabularyWord(
            id = "w_b2_1",
            word = "Resilience",
            ipa = "/rɪˈzɪl.jəns/",
            partOfSpeech = "noun",
            defDari = "تاب‌آوری، استقامت در برابر دشواری",
            defPashto = "ټینګښت، په ستونزو کې زغم او مقاومت",
            defEn = "The capacity to recover quickly from difficulties; toughness",
            exampleEn = "Language learners develop remarkable resilience through mistakes.",
            exampleDari = "زبان‌آموزان از طریق اشتباهات تاب‌آوری شگفت‌انگیزی کسب می‌کنند.",
            examplePashto = "زده کوونکي د تیروتنو له لارې د پام وړ ټینګښت او زغم ترلاسه کوي.",
            collocation = "Demonstrate resilience / Mental resilience",
            commonMistake = "Stress is on the second syllable: re-ZIL-ience.",
            level = LearningLevel.B2
        ),

        // C1
        VocabularyWord(
            id = "w_c1_1",
            word = "Articulate",
            ipa = "/ɑːrˈtɪk.jə.lət/",
            partOfSpeech = "adjective / verb",
            defDari = "فصیح، شیوا، بیان‌کننده دقیق",
            defPashto = "فصیح، روښانه بیانونکی، ژور ویونکی",
            defEn = "Having or showing the ability to speak fluently and coherently",
            exampleEn = "She delivered an articulate speech on international peace.",
            exampleDari = "او یک سخنرانی بسیار فصیح و رسا درباره صلح بین‌المللی ارائه داد.",
            examplePashto = "هغې د نړیوالې سولې په اړه یوه خورا فصیحه او روښانه وینا وړاندې کړه.",
            collocation = "Articulate thoughts / Highly articulate",
            commonMistake = "Pronounced /-lət/ as adjective, /-leɪt/ as verb.",
            level = LearningLevel.C1
        ),

        // C2
        VocabularyWord(
            id = "w_c2_1",
            word = "Eloquent",
            ipa = "/ˈel.ə.kwənt/",
            partOfSpeech = "adjective",
            defDari = "بلیغ، سخنور، پرنفوذ و تأثیرگذار در کلام",
            defPashto = "بلیغ، خوږ ژبی، په وینا کې زړه راښکونکی",
            defEn = "Fluent or persuasive in speaking or writing",
            exampleEn = "Her eloquent arguments convinced the entire academic panel.",
            exampleDari = "استدلال‌های بلیغ او تمام هیئت آکادمیک را متقاعد ساخت.",
            examplePashto = "د هغې بلیغو دلایلو د پوهنتون ټوله علمي کمیټه قانع کړه.",
            collocation = "Eloquent speaker / Eloquent tribute",
            commonMistake = "Don't confuse with 'Elegant' (graceful in appearance).",
            level = LearningLevel.C2
        ),

        // Post-C2 (Expert Domains)
        VocabularyWord(
            id = "w_post_c2_1",
            word = "Jurisprudence",
            ipa = "/ˌdʒʊr.ɪsˈpruː.dəns/",
            partOfSpeech = "noun (Legal)",
            defDari = "علم حقوق، فقه قضایی، فلسفه قانون",
            defPashto = "د حقوقو علم، عدلي فقه، د قانون فلسفه",
            defEn = "The theory or philosophy of law; legal system analysis",
            exampleEn = "Comparative jurisprudence reveals the foundations of global justice.",
            exampleDari = "حقوق تطبیقی، بنیادهای عدالت جهانی را آشکار می‌سازد.",
            examplePashto = "تطبیقي حقوقي پوهه د نړیوال عدالت بنسټونه روښانه کوي.",
            collocation = "Medical jurisprudence / Modern jurisprudence",
            commonMistake = "Specific to legal and scholarly domains.",
            level = LearningLevel.POST_C2
        ),
        VocabularyWord(
            id = "w_post_c2_2",
            word = "Empirical",
            ipa = "/emˈpɪr.ɪ.kəl/",
            partOfSpeech = "adjective (Academic & Science)",
            defDari = "تجربی، مبتنی بر مشاهده و آزمایش مستند",
            defPashto = "تجربوي، پر کتنو او عیني ثبوتونو ولاړ",
            defEn = "Based on, concerned with, or verifiable by observation or experience",
            exampleEn = "The research team published empirical evidence confirming the thesis.",
            exampleDari = "تیم پژوهشی شواهد تجربی مستندی در تأیید این رساله منتشر نمود.",
            examplePashto = "څیړنیزې ډلې د مقالې د ثبوت لپاره عیني تجربوي اسناد خپاره کړل.",
            collocation = "Empirical data / Empirical study",
            commonMistake = "Opposite of 'Theoretical' or 'Speculative'.",
            level = LearningLevel.POST_C2
        ),
        VocabularyWord(
            id = "w_post_c2_3",
            word = "Cognitive",
            ipa = "/ˈkɑːɡ.nə.tɪv/",
            partOfSpeech = "adjective (Medicine & AI)",
            defDari = "شناختی، ادراکی، مربوط به فرایندهای فکری مغز",
            defPashto = "ادراکي، پوهنیز، د ذهن او فکر پورې اړوند",
            defEn = "Relating to conscious mental activities such as thinking, understanding, learning",
            exampleEn = "Language mastery actively enhances neural cognitive flexibility.",
            exampleDari = "تسلط بر زبان، انعطاف‌پذیری شناختی و عصبی مغز را تقویت می‌کند.",
            examplePashto = "د ژبې تسلط د ذهن ادراکي وړتیاوې او عصبي ځواک پیاوړی کوي.",
            collocation = "Cognitive abilities / Cognitive linguistics",
            commonMistake = "Pronounce with hard 'g' (/ɡ/).",
            level = LearningLevel.POST_C2
        )
    )
}
