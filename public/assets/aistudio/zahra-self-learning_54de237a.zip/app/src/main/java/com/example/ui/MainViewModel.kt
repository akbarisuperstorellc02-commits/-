package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.curriculum.AlphabetPhonicsData
import com.example.data.curriculum.ConversationData
import com.example.data.curriculum.GrammarData
import com.example.data.curriculum.StoriesData
import com.example.data.curriculum.VocabularyData
import com.example.data.local.AppDatabase
import com.example.data.local.AssessmentEntity
import com.example.data.local.MistakeEntity
import com.example.data.local.ScheduleEntity
import com.example.data.local.UserProfileEntity
import com.example.data.model.AlphabetLetter
import com.example.data.model.ChatMessage
import com.example.data.model.ConversationScenario
import com.example.data.model.GradedStory
import com.example.data.model.GrammarLesson
import com.example.data.model.LearningLevel
import com.example.data.model.PronunciationResult
import com.example.data.model.VocabularyWord
import com.example.data.model.WritingCorrection
import com.example.data.repository.ZahraRepository
import com.example.engine.OfflineSpeechEngine
import com.example.engine.PronunciationEvaluator
import com.example.engine.TeacherZahraEngine
import com.example.localization.Language
import com.example.receiver.AlarmScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppScreen {
    DASHBOARD,
    TEACHER_CHAT,
    CURRICULUM_PATH,
    ALPHABET_PHONICS,
    VOCABULARY_SRS,
    GRAMMAR_ACADEMY,
    FOUR_SKILLS,
    STORIES_LIBRARY,
    WRITING_LAB,
    ASSESSMENT_REPORT,
    DAILY_SCHEDULE,
    SETTINGS
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application, viewModelScope)
    val repository = ZahraRepository(database)
    val speechEngine = OfflineSpeechEngine(application)

    // User Profile
    val userProfile: StateFlow<UserProfileEntity?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Current Screen
    private val _currentScreen = MutableStateFlow(AppScreen.DASHBOARD)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Navigation Stack for Android BackHandler
    private val screenStack = mutableListOf(AppScreen.DASHBOARD)

    // Active UI Language
    private val _currentLanguage = MutableStateFlow(Language.DARI)
    val currentLanguage: StateFlow<Language> = _currentLanguage.asStateFlow()

    // Active Level Selection
    private val _selectedLevel = MutableStateFlow(LearningLevel.A0)
    val selectedLevel: StateFlow<LearningLevel> = _selectedLevel.asStateFlow()

    // Alphabet / Phonics State
    val alphabetList: List<AlphabetLetter> = AlphabetPhonicsData.letters
    val phonicsBlends = AlphabetPhonicsData.blends
    private val _selectedLetterIndex = MutableStateFlow(0)
    val selectedLetterIndex: StateFlow<Int> = _selectedLetterIndex.asStateFlow()

    // Vocabulary State
    val allVocabList: List<VocabularyWord> = VocabularyData.words
    private val _selectedVocabIndex = MutableStateFlow(0)
    val selectedVocabIndex: StateFlow<Int> = _selectedVocabIndex.asStateFlow()

    // Grammar Lessons State
    val grammarLessons: List<GrammarLesson> = GrammarData.lessons
    private val _selectedGrammarIndex = MutableStateFlow(0)
    val selectedGrammarIndex: StateFlow<Int> = _selectedGrammarIndex.asStateFlow()

    // Stories State
    val storiesList: List<GradedStory> = StoriesData.stories
    private val _selectedStoryIndex = MutableStateFlow(0)
    val selectedStoryIndex: StateFlow<Int> = _selectedStoryIndex.asStateFlow()

    // Conversation State
    val scenariosList: List<ConversationScenario> = ConversationData.scenarios
    private val _activeScenario = MutableStateFlow(scenariosList[0])
    val activeScenario: StateFlow<ConversationScenario> = _activeScenario.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    // Writing Lab State
    private val _writingCorrection = MutableStateFlow<WritingCorrection?>(null)
    val writingCorrection: StateFlow<WritingCorrection?> = _writingCorrection.asStateFlow()

    // Pronunciation Evaluation State
    private val _pronunciationResult = MutableStateFlow<PronunciationResult?>(null)
    val pronunciationResult: StateFlow<PronunciationResult?> = _pronunciationResult.asStateFlow()

    // Daily Schedules from Room
    val schedulesList: StateFlow<List<ScheduleEntity>> = repository.allSchedules
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Latest Assessment Record
    val latestAssessment: StateFlow<AssessmentEntity?> = repository.latestAssessment
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Mastered Words Count
    val masteredWordsCount: StateFlow<Int> = repository.masteredWordsCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 18)

    init {
        // Sync profile language & settings once loaded
        viewModelScope.launch {
            repository.userProfile.collect { profile ->
                if (profile != null) {
                    _currentLanguage.value = Language.fromCode(profile.selectedLanguageCode)
                    speechEngine.setVoiceConfig(profile.voicePitch, profile.speechSpeed, profile.isAccentUS)
                }
            }
        }
        initConversation(scenariosList[0])
    }

    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value != screen) {
            screenStack.add(screen)
            _currentScreen.value = screen
        }
    }

    fun navigateBack(): Boolean {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.lastIndex)
            _currentScreen.value = screenStack.last()
            return true
        }
        return false
    }

    fun setLanguage(lang: Language) {
        _currentLanguage.value = lang
        viewModelScope.launch(Dispatchers.IO) {
            val current = userProfile.value ?: UserProfileEntity()
            repository.saveProfile(current.copy(selectedLanguageCode = lang.code))
        }
    }

    fun toggleTheme() {
        viewModelScope.launch(Dispatchers.IO) {
            val current = userProfile.value ?: UserProfileEntity()
            repository.saveProfile(current.copy(isDarkTheme = !current.isDarkTheme))
        }
    }

    fun updateVoiceConfig(pitch: Float, speed: Float, isUS: Boolean) {
        speechEngine.setVoiceConfig(pitch, speed, isUS)
        viewModelScope.launch(Dispatchers.IO) {
            val current = userProfile.value ?: UserProfileEntity()
            repository.saveProfile(
                current.copy(
                    voicePitch = pitch,
                    speechSpeed = speed,
                    isAccentUS = isUS
                )
            )
        }
    }

    fun setLevel(level: LearningLevel) {
        _selectedLevel.value = level
        viewModelScope.launch(Dispatchers.IO) {
            val current = userProfile.value ?: UserProfileEntity()
            repository.saveProfile(current.copy(currentLevelCode = level.code))
        }
    }

    fun selectLetter(index: Int) {
        _selectedLetterIndex.value = index.coerceIn(0, alphabetList.size - 1)
        _pronunciationResult.value = null
    }

    fun selectVocab(index: Int) {
        _selectedVocabIndex.value = index.coerceIn(0, allVocabList.size - 1)
    }

    fun selectGrammar(index: Int) {
        _selectedGrammarIndex.value = index.coerceIn(0, grammarLessons.size - 1)
    }

    fun selectStory(index: Int) {
        _selectedStoryIndex.value = index.coerceIn(0, storiesList.size - 1)
    }

    fun selectScenario(scenario: ConversationScenario) {
        _activeScenario.value = scenario
        initConversation(scenario)
    }

    private fun initConversation(scenario: ConversationScenario) {
        val initial = ChatMessage(
            id = UUID.randomUUID().toString(),
            isFromTeacher = true,
            text = scenario.initialTeacherMessage,
            translationDari = scenario.descriptionDari,
            translationPashto = scenario.descriptionPashto
        )
        _chatMessages.value = listOf(initial)
    }

    fun sendUserMessage(text: String) {
        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            isFromTeacher = false,
            text = text
        )
        val updated = _chatMessages.value + userMsg
        _chatMessages.value = updated

        // Generate instant intelligent reply from Teacher Zahra
        val teacherReply = TeacherZahraEngine.generateTeacherResponse(
            userText = text,
            scenarioId = _activeScenario.value.id,
            level = _selectedLevel.value,
            lang = _currentLanguage.value
        )
        _chatMessages.value = updated + teacherReply

        // Speak teacher's reply in friendly female voice
        speak(teacherReply.text)
    }

    fun speak(text: String, isSlow: Boolean = false) {
        speechEngine.speak(text, isSlow)
    }

    fun stopSpeaking() {
        speechEngine.stop()
    }

    fun evaluatePronunciation(expected: String, spokenAttempt: String) {
        val result = PronunciationEvaluator.evaluate(expected, spokenAttempt)
        _pronunciationResult.value = result

        // If score is low, save to mistakes history for adaptive repetition
        if (result.score < 60) {
            viewModelScope.launch(Dispatchers.IO) {
                repository.recordMistake(
                    MistakeEntity(
                        category = "Pronunciation",
                        itemPrompt = expected,
                        incorrectAttempt = spokenAttempt,
                        correction = expected,
                        explanationDari = result.feedbackDari,
                        explanationPashto = result.feedbackPashto
                    )
                )
            }
        }
    }

    fun analyzeUserWriting(text: String) {
        val result = TeacherZahraEngine.analyzeWriting(text)
        _writingCorrection.value = result

        if (result.issuesFound.isNotEmpty()) {
            viewModelScope.launch(Dispatchers.IO) {
                for (issue in result.issuesFound) {
                    repository.recordMistake(
                        MistakeEntity(
                            category = "Writing",
                            itemPrompt = issue.snippet,
                            incorrectAttempt = issue.snippet,
                            correction = issue.correction,
                            explanationDari = issue.reasonDari,
                            explanationPashto = issue.reasonPashto
                        )
                    )
                }
            }
        }
    }

    fun toggleSchedule(schedule: ScheduleEntity) {
        val updated = schedule.copy(isEnabled = !schedule.isEnabled)
        viewModelScope.launch(Dispatchers.IO) {
            repository.updateSchedule(updated)
            if (updated.isEnabled) {
                AlarmScheduler.scheduleSession(getApplication(), updated)
            } else {
                AlarmScheduler.cancelSession(getApplication(), updated.id)
            }
        }
    }

    fun addSchedule(titleEn: String, titleDari: String, titlePashto: String, hour: Int, minute: Int, skill: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val entity = ScheduleEntity(
                titleEn = titleEn,
                titleDari = titleDari,
                titlePashto = titlePashto,
                skillTarget = skill,
                hour = hour,
                minute = minute,
                isEnabled = true
            )
            val newId = repository.saveSchedule(entity)
            AlarmScheduler.scheduleSession(getApplication(), entity.copy(id = newId))
        }
    }

    fun deleteSchedule(scheduleId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            AlarmScheduler.cancelSession(getApplication(), scheduleId)
            repository.deleteSchedule(scheduleId)
        }
    }

    fun testAlarmVoiceNow() {
        val voiceMsg = com.example.localization.Strings.reminderVoiceMessage(_currentLanguage.value)
        speak(voiceMsg, false)
    }

    fun recordQuizAnswer(lessonId: String, isCorrect: Boolean, questionText: String, userAnswer: String, correctAnswer: String, explanationDari: String, explanationPashto: String) {
        if (!isCorrect) {
            viewModelScope.launch(Dispatchers.IO) {
                repository.recordMistake(
                    MistakeEntity(
                        category = "Grammar",
                        itemPrompt = questionText,
                        incorrectAttempt = userAnswer,
                        correction = correctAnswer,
                        explanationDari = explanationDari,
                        explanationPashto = explanationPashto
                    )
                )
            }
        }
    }

    fun recordVocabReview(wordId: String, isKnown: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.advanceVocabSrs(wordId, isKnown)
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechEngine.shutdown()
    }
}
