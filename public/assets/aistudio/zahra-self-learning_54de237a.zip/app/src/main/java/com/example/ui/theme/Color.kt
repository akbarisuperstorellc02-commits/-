package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Luxury Deep Obsidian & Gold Palette
val ObsidianBlack = Color(0xFF0B0C10)
val DarkSurface = Color(0xFF13151D)
val DarkSurfaceElevated = Color(0xFF1B1E29)
val DarkSurfaceCard = Color(0xFF222634)
val DarkBorder = Color(0xFF2E3346)

// Gold & Popcorn Soft 3D Accents
val LuxuryGold = Color(0xFFFFD700)
val ChampagneGold = Color(0xFFE5C158)
val WarmGold = Color(0xFFD4AF37)
val SoftGold = Color(0xFFF7E7B4)
val GlowGold = Color(0x33FFD700)

// Popcorn Soft Tactile 3D Extruded Palette
val PopcornCream = Color(0xFFFFF9E6)
val PopcornGold = Color(0xFFFFD666)
val PopcornAmber = Color(0xFFFFB82E)
val PopcornShadow = Color(0xFF9E6500)
val PopcornBorder = Color(0xFFFFF1B8)
val PopcornSurface = Color(0xFF181B26)
val PopcornDarkShadow = Color(0xFF0F1118)

// Semantic Accents
val EmeraldGreen = Color(0xFF2ECC71)
val CrimsonRed = Color(0xFFE74C3C)
val SapphireBlue = Color(0xFF3498DB)
val VioletPurple = Color(0xFF9B59B6)

// Text Colors
val TextPrimaryDark = Color(0xFFF5F6FA)
val TextSecondaryDark = Color(0xFFA4B0BE)
val TextMutedDark = Color(0xFF718093)

// Light Theme Variants
val LightBackground = Color(0xFFF8F9FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFF1F2F6)
val LightBorder = Color(0xFFE4E7EB)
val TextPrimaryLight = Color(0xFF1E272C)
val TextSecondaryLight = Color(0xFF57606F)
