package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.data.local.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED
        ) {
            Log.d("BootReceiver", "Device rebooted or time changed: restoring active study schedules")
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val db = AppDatabase.getDatabase(context, CoroutineScope(Dispatchers.IO))
                    val activeList = db.scheduleDao().getActiveSchedulesList()
                    for (schedule in activeList) {
                        AlarmScheduler.scheduleSession(context, schedule)
                    }
                    Log.d("BootReceiver", "Successfully restored ${activeList.size} study schedules")
                } catch (e: Exception) {
                    Log.e("BootReceiver", "Failed to restore schedules", e)
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
