package com.example.data.curriculum

import com.example.data.model.GrammarExample
import com.example.data.model.GrammarLesson
import com.example.data.model.GrammarQuizQuestion
import com.example.data.model.LearningLevel

object GrammarData {
    val lessons: List<GrammarLesson> = listOf(
        GrammarLesson(
            id = "g_a0_1",
            level = LearningLevel.A0,
            titleEn = "The Verb 'To Be' & Personal Pronouns",
            titleDari = "فعل بودن (To Be) و ضمایر فاعلی",
            titlePashto = "د شتون فعل (To Be) او فاعلي ضمیرونه",
            explanationEn = "The verb 'to be' is the foundation of English sentences. It connects a subject to its state, identity, or quality.",
            explanationDari = "فعل «بودن» (Am / Is / Are) پایه‌ترین فعل زبان انگلیسی است. برای معرفی هویت، سن، ملیت و حالات روحی استفاده می‌شود: I am (من هستم)، You are (شما هستید)، He/She is (او هست)، We are (ما هستیم)، They are (آنها هستند).",
            explanationPashto = "د شتون فعلونه (Am / Is / Are) د انګلیسي ژبې تر ټولو بنسټیز فعلونه دي. د هویت، عمر، او صفتونو د ښودلو لپاره کارول کیږي: I am (زه یم)، You are (ته یې/تاسو یاست)، He/She is (هغه دی/ده)، We are (موږ یو)، They are (دوی دي).",
            formula = "Subject + [am / is / are] + Complement (Noun / Adjective)",
            examples = listOf(
                GrammarExample("I am a student.", "من یک دانش‌آموز هستم.", "زه یو زده کوونکی یم."),
                GrammarExample("Zahra is a kind teacher.", "زهرا یک معلم مهربان است.", "زهرا یوه مهربانه استاده ده."),
                GrammarExample("We are happy to learn English.", "ما از یادگیری انگلیسی خوشحالیم.", "موږ د انګلیسي په زده کړه خوشاله یو.")
            ),
            quiz = listOf(
                GrammarQuizQuestion(
                    question = "She _____ very smart and diligent.",
                    options = listOf("am", "is", "are", "be"),
                    correctIndex = 1,
                    explanationEn = "We use 'is' with third-person singular subjects (He, She, It).",
                    explanationDari = "برای ضمایر سوم شخص مفرد (او مذکر یا مؤنث) همیشه از 'is' استفاده می‌شود.",
                    explanationPashto = "د مفرد دریم کس لپاره (He, She, It) تل 'is' کارول کیږي."
                ),
                GrammarQuizQuestion(
                    question = "They _____ studying in the library.",
                    options = listOf("is", "am", "are", "was"),
                    correctIndex = 2,
                    explanationEn = "We use 'are' with plural subjects (We, You, They).",
                    explanationDari = "برای فاعل‌های جمع (They) همیشه 'are' به کار می‌رود.",
                    explanationPashto = "د جمع فاعلونو لپاره (They) تل 'are' راځي."
                )
            )
        ),

        GrammarLesson(
            id = "g_a1_1",
            level = LearningLevel.A1,
            titleEn = "Present Simple & Daily Habits",
            titleDari = "حال ساده و عادات روزمره",
            titlePashto = "ساده اوسمهال او ورځني عادتونه",
            explanationEn = "Use Present Simple to describe facts, routines, and regular habits. Add -s or -es for He, She, It.",
            explanationDari = "زمان حال ساده برای کارهای همیشگی، عادت‌ها و حقایق جهان به کار می‌رود. نکته طلایی: برای He / She / It در جملات مثبت به آخر فعل s یا es اضافه کنید (مثل: She learns).",
            explanationPashto = "ساده اوسمهال د ورځنیو کارونو، عادتونو او نړیوالو حقایقو لپاره کاریږي. مهمه لارښوونه: د He / She / It لپاره د فعل په پای کې s یا es زیاتیږي.",
            formula = "Subject + Verb(s/es) + Object | Negative: don't / doesn't + base verb",
            examples = listOf(
                GrammarExample("I practice English every single day.", "من هر روز انگلیسی تمرین می‌کنم.", "زه هره ورځ انګلیسي تمرین کوم."),
                GrammarExample("Zahra teaches with immense patience.", "زهرا با صبری بی‌پایان تدریس می‌کند.", "زهرا په ډیر زغم او صبر درس ورکوي."),
                GrammarExample("He does not give up easily.", "او به آسانی تسلیم نمی‌شود.", "هغه په اسانۍ نه تسلیمیږي.")
            ),
            quiz = listOf(
                GrammarQuizQuestion(
                    question = "My brother _____ to work by train every morning.",
                    options = listOf("go", "goes", "going", "went"),
                    correctIndex = 1,
                    explanationEn = "Third person singular (My brother = He) takes 'goes'.",
                    explanationDari = "برای فاعل مفرد غایب فعل به es نیاز دارد: goes.",
                    explanationPashto = "د مفرد غایب فاعل لپاره د فعل په پای کې es زیاتیږي: goes."
                )
            )
        ),

        GrammarLesson(
            id = "g_a2_1",
            level = LearningLevel.A2,
            titleEn = "Past Simple & Regular/Irregular Verbs",
            titleDari = "زمان گذشته ساده و افعال باقاعده و بی‌قاعده",
            titlePashto = "ساده تېرمهال او باقاعده او بې قاعده فعلونه",
            explanationEn = "Describes actions completed at a specific time in the past. Regular verbs take -ed, while irregular verbs change form (go -> went, see -> saw).",
            explanationDari = "برای رویدادهایی که در گذشته در زمانی معین انجام و تمام شده‌اند استفاده می‌شود. افعال باقاعده پسوند ed می‌گیرند و افعال بی‌قاعده شکل‌شان عوض می‌شود.",
            explanationPashto = "د هغو کارونو لپاره کاریږي چې په تېر وخت کې پای ته رسیدلي وي. باقاعده فعلونه ed اخلي او بې قاعده فعلونه خپل شکل بدلوي.",
            formula = "Subject + V2 (Past form) + Object | Negative: did not + base verb",
            examples = listOf(
                GrammarExample("Yesterday, I learned twenty new words.", "دیروز من بیست واژه جدید یاد گرفتم.", "پرون ما شل نوي لغتونه زده کړل."),
                GrammarExample("We spoke with Zahra for an hour.", "ما به مدت یک ساعت با زهرا صحبت کردیم.", "موږ یو ساعت له زهرا سره خبرې وکړې.")
            ),
            quiz = listOf(
                GrammarQuizQuestion(
                    question = "She _____ to the capital last week.",
                    options = listOf("travel", "traveled", "traveling", "travels"),
                    correctIndex = 1,
                    explanationEn = "Regular verb 'travel' becomes 'traveled' in past simple.",
                    explanationDari = "فعل باقاعده با پسوند ed به گذشته تبدیل می‌شود: traveled.",
                    explanationPashto = "باقاعده فعل د ed په اضافه کولو سره تېر مهال جوړوي: traveled."
                )
            )
        ),

        GrammarLesson(
            id = "g_b1_1",
            level = LearningLevel.B1,
            titleEn = "Present Perfect & Life Experiences",
            titleDari = "حال کامل و تجربیات گذشته تا کنون",
            titlePashto = "بشپړ اوسمهال او د ژوند تجربې",
            explanationEn = "Connects the past to the present. Used for life experiences, unfinished actions, or past actions with present consequences.",
            explanationDari = "این زمان گذشته را به حال وصل می‌کند. وقتی کاری در گذشته انجام شده اما زمان دقیق آن مشخص نیست یا اثر آن در زمان حال باقی مانده است: Have/Has + اسم مفعول (V3).",
            explanationPashto = "دا زمان تېر وخت له اوس سره نښلوي. کله چې کار ترسره شوی وي مګر دقیق وخت یې نه وي ښودل شوی او اغیز یې اوس هم وي.",
            formula = "Subject + have/has + Past Participle (V3)",
            examples = listOf(
                GrammarExample("I have studied English for six months.", "من به مدت شش ماه انگلیسی خوانده‌ام.", "ما شپږ میاشتې انګلیسي لوستې ده."),
                GrammarExample("Have you ever visited Kabul or Herat?", "آیا تا به حال از کابل یا هرات دیدن کرده‌اید؟", "ایا کله دې له کابل یا هرات څخه لیدنه کړې؟")
            ),
            quiz = listOf(
                GrammarQuizQuestion(
                    question = "Zahra _____ already finished evaluating your essay.",
                    options = listOf("have", "has", "is", "was"),
                    correctIndex = 1,
                    explanationEn = "Singular subject 'Zahra' uses auxiliary 'has'.",
                    explanationDari = "برای فاعل مفرد از کمکی 'has' استفاده می‌شود.",
                    explanationPashto = "د مفرد فاعل لپاره 'has' مرستیال فعل راځي."
                )
            )
        ),

        GrammarLesson(
            id = "g_b2_1",
            level = LearningLevel.B2,
            titleEn = "Passive Voice (Form, Use & Style)",
            titleDari = "ساختار مجهول و تغییر کانون توجه",
            titlePashto = "مجهولې جملې او د تمرکز بدلون",
            explanationEn = "Used when the focus is on the action itself or when the doer is unknown, irrelevant, or intentionally omitted for academic neutrality.",
            explanationDari = "در جملات مجهول، مفعول جای فاعل قرار می‌گیرد چون خود رویداد یا اثر کار مهم‌تر از شخص انجام‌دهنده است. در متون رسمی و علمی بسیار پرکاربرد است.",
            explanationPashto = "په مجهولو جملو کې عمل تر ترسره کوونکي ډیر مهم وي. په علمي او رسمي لیکنو کې خورا ډیر کاریږي.",
            formula = "Object + Appropriate Form of 'Be' + V3 (Past Participle)",
            examples = listOf(
                GrammarExample("The scholarship was awarded to the top scholar.", "بورسیه تحصیلی به دانش‌پژوه برتر اعطا شد.", "تحصیلي بورس د غوره څیړونکي په برخه شو."),
                GrammarExample("English is spoken worldwide.", "زبان انگلیسی در سرتاسر جهان صحبت می‌شود.", "انګلیسي ژبه په ټوله نړۍ کې ویل کیږي.")
            ),
            quiz = listOf(
                GrammarQuizQuestion(
                    question = "The groundbreaking report _____ published last month.",
                    options = listOf("was", "were", "is", "be"),
                    correctIndex = 0,
                    explanationEn = "Singular subject in past simple passive takes 'was + V3'.",
                    explanationDari = "فاعل مفرد در گذشته مجهول نیاز به 'was' دارد.",
                    explanationPashto = "مفرد فاعل په تېر مجهول مهال کې 'was' اخلي."
                )
            )
        ),

        GrammarLesson(
            id = "g_c1_1",
            level = LearningLevel.C1,
            titleEn = "Conditionals Mastery & Inversion",
            titleDari = "تسلط بر جملات شرطی و ساختار واژگونی (Inversion)",
            titlePashto = "د شرطیه جوړښتونو او د جملې د ترتیب اوښتون (Inversion)",
            explanationEn = "Advanced conditional hypothetical structures and dramatic inversion to emphasize exclusivity, rarity, or formal conviction.",
            explanationDari = "جملات شرطی نوع سوم و ترکیبی برای فرضیات گذشته و ساختار واژگونی (قرار گرفتن فعل کمکی قبل از فاعل) برای تأکید ویژه در سخنرانی‌های فاخر و مقالات سطح بالا استفاده می‌شوند.",
            explanationPashto = "د شرطیه جوړښتونو لوړ کچې او د فعل مخکې راوستل د خبرو د پیاوړتیا او رسمي ښکلا لپاره کاریږي.",
            formula = "Had + Subject + V3, Subject + would have + V3 | Seldom / Never + Auxiliary + Subject",
            examples = listOf(
                GrammarExample("Had you informed me, I would have prepared the dossier.", "اگر مرا مطلع می‌ساختید، پرونده را آماده می‌کردم.", "که تاسو ماته خبر راکړی وای، ما به دوسیه چمتو کړې وای."),
                GrammarExample("Never have I witnessed such profound dedication.", "هرگز چنین فداکاری عمیقی را ندیده بودم.", "ما هیڅکله داسې ژوره سرښندنه نه وه لیدلې.")
            ),
            quiz = listOf(
                GrammarQuizQuestion(
                    question = "Seldom _____ such remarkable eloquence in a student debate.",
                    options = listOf("we hear", "have we heard", "we had heard", "we heard"),
                    correctIndex = 1,
                    explanationEn = "Negative adverb 'Seldom' triggers auxiliary inversion: 'have we heard'.",
                    explanationDari = "قید منفی Seldom در ابتدای جمله ساختار واژگونی ایجاد می‌کند: have we heard.",
                    explanationPashto = "منفي قید Seldom د جملې په پیل کې د فعل مخکې کیدل غواړي: have we heard."
                )
            )
        ),

        GrammarLesson(
            id = "g_post_c2_1",
            level = LearningLevel.POST_C2,
            titleEn = "Subjunctive Mood & Epistemic Stance in Scholarly Discourse",
            titleDari = "وجه التزامی حقوقی و مواضع معرفت‌شناختی در نگارش آکادمیک",
            titlePashto = "په حقوقي او علمي لیکنو کې التزامي بڼه او علمي دریځ",
            explanationEn = "The mandative subjunctive and nuanced hedging modals used by jurists, senior scientists, and international diplomats to calibrate certainty and mandate protocol.",
            explanationDari = "وجه التزامی (Subjunctive) از شکل پایه فعل بدون s حتی برای سوم شخص استفاده می‌کند: It is imperative that he attend. همچنین تعدیل ادعا (Hedging) دقت علمی مقالات معتبر جهان را تضمین می‌کند.",
            explanationPashto = "دا التزامي بڼه په رسمي، حقوقي او لوړو علمي څیړنو کې د پریکړو او احتمالي حدودو د دقیق بیان لپاره کارول کیږي.",
            formula = "It is [imperative / vital / essential] that + Subject + [base verb bare infinitive]",
            examples = listOf(
                GrammarExample("The legal tribunal demanded that the witness be present.", "دادگاه حقوقی مقرر داشت که شاهد حاضر باشد.", "عدلي محکمې امر وکړ چې شاهد باید حاضر وي."),
                GrammarExample("The empirical data suggest that these findings warrant further study.", "داده‌های تجربی نشان می‌دهند که این یافته‌ها نیازمند بررسی بیشتری هستند.", "عیني تجربوي معلومات څرګندوي چې دا موندنې لا زیاتې څیړنې ته اړتیا لري.")
            ),
            quiz = listOf(
                GrammarQuizQuestion(
                    question = "It is essential that each investigator _____ the ethical protocol.",
                    options = listOf("follows", "follow", "followed", "following"),
                    correctIndex = 1,
                    explanationEn = "The mandative subjunctive mandates bare infinitive 'follow' after essential that.",
                    explanationDari = "وجه التزامی فرم ساده فعل بدون هیچ پسوندی (follow) را طلب می‌کند.",
                    explanationPashto = "التزامي بڼه د فعل ساده او اصلي حالت (follow) غواړي."
                )
            )
        )
    )
}
