package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = LuxuryGold,
    onPrimary = ObsidianBlack,
    primaryContainer = WarmGold.copy(alpha = 0.2f),
    onPrimaryContainer = SoftGold,
    secondary = ChampagneGold,
    onSecondary = ObsidianBlack,
    secondaryContainer = DarkSurfaceElevated,
    onSecondaryContainer = SoftGold,
    tertiary = EmeraldGreen,
    onTertiary = Color.White,
    background = ObsidianBlack,
    onBackground = TextPrimaryDark,
    surface = DarkSurface,
    onSurface = TextPrimaryDark,
    surfaceVariant = DarkSurfaceElevated,
    onSurfaceVariant = TextSecondaryDark,
    outline = DarkBorder,
    outlineVariant = GlowGold,
    error = CrimsonRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = WarmGold,
    onPrimary = Color.White,
    primaryContainer = SoftGold.copy(alpha = 0.35f),
    onPrimaryContainer = ObsidianBlack,
    secondary = ChampagneGold,
    onSecondary = ObsidianBlack,
    secondaryContainer = LightSurfaceElevated,
    onSecondaryContainer = ObsidianBlack,
    tertiary = EmeraldGreen,
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = TextPrimaryLight,
    surface = LightSurface,
    onSurface = TextPrimaryLight,
    surfaceVariant = LightSurfaceElevated,
    onSurfaceVariant = TextSecondaryLight,
    outline = LightBorder,
    outlineVariant = WarmGold.copy(alpha = 0.25f),
    error = CrimsonRed,
    onError = Color.White
)

@Composable
fun ZahraTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
