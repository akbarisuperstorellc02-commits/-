package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Language
import com.example.ui.MainViewModel
import com.example.ui.components.LevelBadge
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

@Composable
fun StoriesScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val stories = viewModel.storiesList
    val selectedIndex by viewModel.selectedStoryIndex.collectAsState()
    val currentStory = stories[selectedIndex]

    var showTranslation by remember(selectedIndex) { mutableStateOf(false) }
    var selectedOption by remember(selectedIndex) { mutableStateOf<Int?>(null) }
    var answered by remember(selectedIndex) { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Stories Carousel
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                itemsIndexed(stories) { index, story ->
                    val isSelected = index == selectedIndex
                    com.example.ui.components.PopcornPillTab(
                        title = story.titleEn,
                        badge = story.level.code,
                        isSelected = isSelected,
                        onClick = {
                            viewModel.selectStory(index)
                            showTranslation = false
                            selectedOption = null
                            answered = false
                        }
                    )
                }
            }
        }

        // Story Reader Card
        item {
            LuxuryGlassCard(
                modifier = Modifier.testTag("story_reader_card"),
                borderColor = LuxuryGold
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LevelBadge(levelCode = currentStory.level.code)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        com.example.ui.components.PopcornCircleButton(
                            icon = Icons.Default.VolumeUp,
                            contentDescription = "Read Aloud",
                            onClick = { viewModel.speak(currentStory.fullTextEn) },
                            size = 42.dp
                        )

                        com.example.ui.components.PopcornCircleButton(
                            icon = Icons.Default.Speed,
                            contentDescription = "Read Slow",
                            onClick = { viewModel.speak(currentStory.fullTextEn, isSlow = true) },
                            size = 42.dp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = currentStory.titleEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = LuxuryGold
                )

                val subTitle = when (lang) {
                    Language.DARI -> currentStory.titleDari
                    Language.PASHTO -> currentStory.titlePashto
                    Language.ENGLISH -> ""
                }
                if (subTitle.isNotEmpty()) {
                    Text(
                        text = subTitle,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Full Story Text in English
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(DarkSurfaceElevated)
                        .padding(16.dp)
                ) {
                    Text(
                        text = currentStory.fullTextEn,
                        fontSize = 15.sp,
                        lineHeight = 26.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Key Words Tags
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "Keywords:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = LuxuryGold
                    )
                    currentStory.keyWords.forEach { word ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = LuxuryGold.copy(alpha = 0.1f),
                            modifier = Modifier.clickable { viewModel.speak(word) }
                        ) {
                            Text(
                                text = word,
                                fontSize = 12.sp,
                                color = SoftGold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Toggle Translation Button
                Button(
                    onClick = { showTranslation = !showTranslation },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlowGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Translate, contentDescription = null, tint = LuxuryGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (showTranslation) "پنهان کردن ترجمه" else "نمایش ترجمه روان داستان",
                        color = SoftGold,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (showTranslation) {
                    Spacer(modifier = Modifier.height(10.dp))
                    val translation = if (lang == Language.PASHTO) currentStory.fullTextPashto else currentStory.fullTextDari
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkSurfaceElevated)
                            .padding(14.dp)
                    ) {
                        Text(
                            text = translation,
                            fontSize = 14.sp,
                            lineHeight = 24.sp,
                            color = SoftGold
                        )
                    }
                }
            }
        }

        // Reading Comprehension Check Card
        item {
            LuxuryGlassCard(borderColor = GlowGold) {
                Text(
                    text = "درک مطلب داستان (Reading Comprehension):",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = LuxuryGold
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = currentStory.comprehensionQuestion,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(12.dp))

                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    currentStory.options.forEachIndexed { idx, opt ->
                        val isSelected = selectedOption == idx
                        val isCorrect = idx == currentStory.correctOptionIndex
                        val optState = when {
                            answered && isCorrect -> true
                            answered && isSelected && !isCorrect -> false
                            else -> null
                        }

                        com.example.ui.components.PopcornSelectableOption(
                            text = opt,
                            isSelected = isSelected,
                            prefixNumber = idx + 1,
                            isCorrect = optState,
                            enabled = !answered,
                            onClick = {
                                selectedOption = idx
                            }
                        )
                    }
                }

                if (!answered) {
                    Spacer(modifier = Modifier.height(14.dp))
                    com.example.ui.components.GoldButton(
                        text = "ارزیابی پاسخ (Evaluate)",
                        onClick = { answered = true },
                        enabled = selectedOption != null,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
