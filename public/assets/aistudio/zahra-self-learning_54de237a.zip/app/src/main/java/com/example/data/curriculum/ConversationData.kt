package com.example.data.curriculum

import com.example.data.model.ConversationScenario

object ConversationData {
    val scenarios: List<ConversationScenario> = listOf(
        ConversationScenario(
            id = "sc_free",
            iconName = "chat",
            titleEn = "Free Casual Talk with Teacher Gohari",
            titleDari = "گفتگوی آزاد و صمیمی با استاد گوهری",
            titlePashto = "له استاده ګوهري سره ازادې او صمیمي خبرې",
            descriptionEn = "Practice natural English about your day, ambitions, hobbies, and learning progress.",
            descriptionDari = "تمرین مکالمه طبیعی درباره کارهای روزمره، اهداف، علایق و پیشرفت در یادگیری.",
            descriptionPashto = "د ورځني ژوند، اهدافو، شوقونو او زده کړې پرمختګ په اړه طبیعي خبرې.",
            initialTeacherMessage = "Hello dear! It's so lovely to speak with you today. How are you feeling, and what would you like to talk about?",
            suggestedUserResponses = listOf(
                "Hello Teacher Gohari! I am feeling great and excited to learn.",
                "I would love to practice speaking about my daily routine.",
                "Can you help me practice for an English test?",
                "Tell me an interesting fact about the English language."
            )
        ),
        ConversationScenario(
            id = "sc_job_interview",
            iconName = "work",
            titleEn = "Job & Scholarship Interview",
            titleDari = "مصاحبه کاری و اخذ بورسیه تحصیلی",
            titlePashto = "د دندې او تحصیلي بورس مرکه",
            descriptionEn = "Master professional questions, salary negotiation, and presenting your greatest strengths.",
            descriptionDari = "پاسخ به سوالات کلیدی مصاحبه‌کنندگان، بیان توانمندی‌ها و تسلط بر کلام حرفه‌ای.",
            descriptionPashto = "د مرکې کونکو مهمو پوښتنو ته ځواب، د وړتیاوو بیان او مسلکي کلام.",
            initialTeacherMessage = "Welcome to our interview session. Thank you for coming today. Could you please introduce yourself and highlight your key achievements?",
            suggestedUserResponses = listOf(
                "Thank you for having me. My background is in technology and data analysis.",
                "I am a passionate problem solver who thrives under tight deadlines.",
                "Over the past three years, I led several successful community projects.",
                "I believe my adaptability and dedication make me an ideal candidate."
            )
        ),
        ConversationScenario(
            id = "sc_airport",
            iconName = "flight",
            titleEn = "Airport & Border Customs",
            titleDari = "میدان هوایی، بررسی پاسپورت و گمرک",
            titlePashto = "هوایي ډګر، پاسپورټ کتل او ګمرک",
            descriptionEn = "Navigate flight check-in, baggage declaration, and security check with ease.",
            descriptionDari = "تحویل بار، سوالات افسر مهاجرت و دریافت کارت پرواز بدون استرس.",
            descriptionPashto = "د سامان سپارل، د پاسپورټ کتنې پوښتنې او د الوتنې د کارت ترلاسه کول.",
            initialTeacherMessage = "Good day! May I please see your passport and flight boarding pass? Are you traveling for business or pleasure?",
            suggestedUserResponses = listOf(
                "Here is my passport and electronic boarding pass.",
                "I am traveling for an international academic conference.",
                "I only have one carry-on luggage and no prohibited goods.",
                "Could you please tell me which gate my connecting flight departs from?"
            )
        ),
        ConversationScenario(
            id = "sc_doctor",
            iconName = "local_hospital",
            titleEn = "Doctor's Clinic & Health",
            titleDari = "مطب داکتر و بیان وضعیت صحی",
            titlePashto = "د ډاکټر کلینیک او روغتیا",
            descriptionEn = "Describe physical symptoms, allergies, and ask for clear prescription guidance.",
            descriptionDari = "شرح علائم بیماری، حساسیت‌ها، درد و دریافت دستورالعمل دقیق داروها.",
            descriptionPashto = "د ناروغۍ د نښو تشریح، حساسیتونه، درد او د درملو د کارونې لارښوونه.",
            initialTeacherMessage = "Hello. Please have a seat. What seems to be troubling you today, and how long have you felt these symptoms?",
            suggestedUserResponses = listOf(
                "I have been having a severe headache and sore throat since yesterday.",
                "I feel quite dizzy and have a mild fever.",
                "Are there any side effects to this medication?",
                "Do I need to rest for a couple of days?"
            )
        ),
        ConversationScenario(
            id = "sc_restaurant",
            iconName = "restaurant",
            titleEn = "Restaurant & Fine Dining",
            titleDari = "رستورانت، سفارش غذا و حساب",
            titlePashto = "رستورانت، د خوړو فرمایش او حساب",
            descriptionEn = "Order dishes, inquire about ingredients, and request the check politely.",
            descriptionDari = "سفارش غذای دلخواه، پرسش درباره محتویات غذا و پرداخت محترمانه بل.",
            descriptionPashto = "د خوښې خواړه غوښتل، د خوراک د اجزاوو پوښتنه او د بل ادا کول.",
            initialTeacherMessage = "Good evening! Welcome to our restaurant. Have you had a chance to look at the menu, or may I recommend our chef's special?",
            suggestedUserResponses = listOf(
                "Good evening! What would you recommend for a light dinner?",
                "Could I please order the grilled salmon with vegetables?",
                "Does this soup contain any nuts or dairy products?",
                "We are ready for the check, please. Thank you for the wonderful service."
            )
        )
    )
}
