package com.example.engine

import com.example.data.model.ChatMessage
import com.example.data.model.LearningLevel
import com.example.data.model.WritingCorrection
import com.example.data.model.WritingIssue
import com.example.localization.Language
import java.util.UUID

object TeacherZahraEngine {

    fun generateTeacherResponse(
        userText: String,
        scenarioId: String,
        level: LearningLevel,
        lang: Language
    ): ChatMessage {
        val lower = userText.trim().lowercase()

        // 1. Contextual Scenario Checks
        val (enReply, dariReply, pashtoReply) = when {
            scenarioId == "sc_job_interview" -> handleInterviewResponse(lower)
            scenarioId == "sc_airport" -> handleAirportResponse(lower)
            scenarioId == "sc_doctor" -> handleDoctorResponse(lower)
            scenarioId == "sc_restaurant" -> handleRestaurantResponse(lower)
            else -> handleGeneralConversation(lower, level)
        }

        return ChatMessage(
            id = UUID.randomUUID().toString(),
            isFromTeacher = true,
            text = enReply,
            translationDari = dariReply,
            translationPashto = pashtoReply
        )
    }

    private fun handleInterviewResponse(text: String): Triple<String, String, String> {
        return when {
            text.contains("technology") || text.contains("developer") || text.contains("engineer") -> Triple(
                "That sounds impressive! How do you handle challenging technical deadlines and team communication?",
                "بسیار عالی و چشمگیر است! شما معمولاً چطور با ضرب‌الاجل‌های فشرده فنی و هماهنگی درون تیمی کنار می‌آیید؟",
                "ډیر عالي او اغیزناک دی! تاسو څنګه له سختو تخنیکي وختونو او ډله ایزو اړیکو سره چلند کوئ؟"
            )
            text.contains("strength") || text.contains("adapt") || text.contains("passion") -> Triple(
                "Adaptability is one of the most valued traits in international organizations. Could you give me a specific real-world example?",
                "انعطاف‌پذیری یکی از باارزش‌ترین ویژگی‌ها در سازمان‌های بین‌المللی است. می‌توانید یک نمونه عینی از تجربیات گذشته‌تان مثال بزنید؟",
                "تطابق منل په نړیوالو ادارو کې تر ټولو ارزښتناکه ځانګړنه ده. ایا کولی شئ د تیرو تجربو څخه یوه دقیقه بیلګه وړاندې کړئ؟"
            )
            else -> Triple(
                "Well articulated! In professional English, maintaining confident eye contact and steady pacing makes your response even more memorable.",
                "بسیار شیوا و رسا بیان کردید! در مکالمه حرفه‌ای انگلیسی، حفظ آرامش و آهنگ یکنواخت کلام، پاسخ شما را ماندگارتر می‌سازد.",
                "ډیر په ښکلي ډول مو بیان کړل! په مسلکي انګلیسي کې، په ډاډه توګه او په ارامه سرعت خبرې کول ستاسو ځواب پیاوړی کوي."
            )
        }
    }

    private fun handleAirportResponse(text: String): Triple<String, String, String> {
        return when {
            text.contains("passport") || text.contains("boarding") -> Triple(
                "Thank you. Your documents are verified. You may proceed to Security Gate 14. Have a pleasant flight!",
                "تشکر. اسناد شما تأیید شد. می‌توانید به سمت گیت بازرسی شماره ۱۴ حرکت نمایید. پرواز خوشی داشته باشید!",
                "مننه. ستاسو اسناد تایید شول. تاسو کولی شئ د ۱۴ نمبر دروازې ته لاړ شئ. ښه الوتنه ولرئ!"
            )
            text.contains("gate") || text.contains("depart") -> Triple(
                "Your gate is located on the second floor, right next to the departure lounge. Boarding starts in forty minutes.",
                "گیت خروجی شما در طبقه دوم، دقیقاً کنار سالن انتظار پرواز قرار دارد. سوار شدن تا چهل دقیقه دیگر آغاز می‌شود.",
                "ستاسو د وتلو دروازه په دوهم پوړ کې د الوتنې د انتظار ځای تر څنګ ده. په الوتکه کې پورته کیدل ۴۰ دقیقې وروسته پیل کیږي."
            )
            else -> Triple(
                "Everything looks in order. Remember to keep your identification readily accessible throughout your travels.",
                "همه چیز منظم و کامل به نظر می‌رسد. به خاطر داشته باشید که مدرک شناسایی‌تان در طول سفر در دسترس باشد.",
                "هرڅه سم او منظم ښکاري. په یاد ولرئ چې د سفر په اوږدو کې خپل پیژندپاڼه په اسانۍ د لاسرسي وړ وساتئ."
            )
        }
    }

    private fun handleDoctorResponse(text: String): Triple<String, String, String> {
        return when {
            text.contains("headache") || text.contains("fever") || text.contains("pain") -> Triple(
                "I understand. I am prescribing a gentle pain reliever and recommending adequate hydration. Make sure to get plenty of rest.",
                "متوجه شدم. برای شما مسکن ملایمی می‌نویسم و توصیه می‌کنم آب کافی بنوشید. حتماً استراحت کامل داشته باشید.",
                "زه پوه شوم. زه تاسو ته یو اراموونکی درمل لیکم او ډیرو اوبو څښلو سپارښتنه کوم. هڅه وکړئ پوره استراحت وکړئ."
            )
            else -> Triple(
                "I will monitor your vital signs. If these symptoms persist beyond three days, please return immediately for a follow-up.",
                "علائم حیاتی شما را بررسی خواهم کرد. اگر این نشانه‌ها بیش از سه روز ادامه یافت، لطفاً برای معاینه مجدد مراجعه نمایید.",
                "زه به ستاسو نښې وڅیړم. که دا حالت تر ۳ ورځو زیات دوام وکړي، مهرباني وکړئ سمدستي بیا کلینیک ته راشئ."
            )
        }
    }

    private fun handleRestaurantResponse(text: String): Triple<String, String, String> {
        return when {
            text.contains("check") || text.contains("bill") -> Triple(
                "Right away! Here is your itemized bill. Would you prefer paying with card or cash?",
                "فوراً خدمت شما! این فاکتور شماست. مایلید با کارت پرداخت فرمایید یا نقدی؟",
                "سمدستي! دا ستاسو بل دی. ایا په کارت پیسې ورکوئ که په نغدو؟"
            )
            text.contains("recommend") || text.contains("dinner") -> Triple(
                "Our grilled salmon seasoned with fresh herbs and saffron rice is our guests' absolute favorite tonight.",
                "ماهی سالمون گریل شده همراه با سبزیجات تازه و برنج زعفرانی، محبوب‌ترین غذای امشب مهمانان ماست.",
                "د سبزیجاتو او زعفراني وریجو سره پاخه شوي ماهي نن شپه زموږ د میلمنو تر ټولو خوښ شوی خواړه دی."
            )
            else -> Triple(
                "Excellent choice! I have placed your order with our chef. It will be served hot within fifteen minutes.",
                "انتخاب فوق‌العاده‌ای است! سفارش شما را ثبت کردم. تا پانزده دقیقه دیگر کاملاً گرم سرو خواهد شد.",
                "خورا ښه انتخاب! ما ستاسو فرمایش ثبت کړ. په پنځلسو دقیقو کې به ګرم تیار شي."
            )
        }
    }

    private fun handleGeneralConversation(lower: String, level: LearningLevel): Triple<String, String, String> {
        return when {
            lower.contains("hello") || lower.contains("hi") || lower.contains("gohari") || lower.contains("zahra") -> Triple(
                "Hello dear friend! I am delighted to practice with you. What exciting milestone are we aiming for today?",
                "سلام دوست عزیزم! از تمرین با شما بسیار خوشحالم. امروز برای چه هدف جذابی تلاش می‌کنیم؟",
                "سلام زما ګران ملګری! ستاسو سره په تمرین ډیره خوشاله یم. نن د کوم زړه راښکونکي هدف لپاره هڅه کوو؟"
            )
            lower.contains("how are you") -> Triple(
                "I am doing wonderfully, thank you for asking! Seeing your steady commitment brings me great joy.",
                "حال من بسیار عالی است، تشکر از احوالپرسی شما! دیدن پشتکار و تعهد شما مایه افتخار و خوشحالی من است.",
                "زه خورا ښه یم، ستاسو له پوښتنې ډیره مننه! ستاسو د پرله پسې هڅو لیدل ما ډیره خوشاله کوي."
            )
            lower.contains("practice") || lower.contains("learn") -> Triple(
                "Consistency is the true key to fluency. Try to build a complete sentence describing your morning routine.",
                "استمرار در تمرین کلید اصلی روانی در کلام است. سعی کنید یک جمله کامل درباره کارهای صبحگاه‌تان بسازید.",
                "په تمرین کې دوام د روانو خبرو اصلي کیلي ده. هڅه وکړئ د خپل سهارني کارونو په اړه یوه بشپړه جمله جوړه کړئ."
            )
            else -> Triple(
                "That is very thoughtful! You used clear vocabulary. Let's expand on that: how would you express that in formal English?",
                "نکته بسیار زیبایی بود! از کلمات بسیار خوبی استفاده کردید. بیایید آن را بسط دهیم: این جمله را در انگلیسی رسمی چگونه بیان می‌کردید؟",
                "ډیره ښکلې خبره وه! تاسو خورا ښه لغتونه وکارول. راځئ چې پراخه یې کړو: دا خبره به په رسمي انګلیسي کې څنګه کوئ؟"
            )
        }
    }

    fun analyzeWriting(text: String): WritingCorrection {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) {
            return WritingCorrection(
                originalText = "",
                correctedText = "",
                score = 0,
                grammarScore = 0,
                vocabScore = 0,
                coherenceScore = 0,
                issuesFound = emptyList(),
                overallRemarksDari = "لطفاً متنی برای بررسی وارد کنید.",
                overallRemarksPashto = "مهرباني وکړئ د کتنې لپاره یو متن ولیکئ.",
                overallRemarksEn = "Please provide text for evaluation."
            )
        }

        val issues = mutableListOf<WritingIssue>()
        var corrected = trimmed

        // Rule 1: Capitalize first letter of sentences
        if (trimmed.isNotEmpty() && trimmed[0].isLowerCase()) {
            issues.add(
                WritingIssue(
                    snippet = trimmed.take(5),
                    correction = trimmed.take(5).replaceFirstChar { it.uppercaseChar() },
                    ruleType = "Capitalization",
                    reasonDari = "در زبان انگلیسی همیشه حرف اول آغاز هر جمله باید بزرگ (Capital) باشد.",
                    reasonPashto = "په انګلیسي کې د هرې جملې لومړنی توری باید خامخا لوی (Capital) وي.",
                    reasonEn = "Sentences must start with a capitalized letter."
                )
            )
            corrected = corrected.replaceFirstChar { it.uppercaseChar() }
        }

        // Rule 2: "I am agree" -> "I agree"
        if (Regex("(?i)\\bi am agree\\b").containsMatchIn(corrected)) {
            issues.add(
                WritingIssue(
                    snippet = "I am agree",
                    correction = "I agree",
                    ruleType = "Subject-Verb Agreement",
                    reasonDari = "واژه Agree خود یک فعل است، نه صفت. بنابراین نیازی به فعل am ندارد و باید گفت: I agree.",
                    reasonPashto = "کلمه Agree پخپله یو فعل دی، صفت نه دی؛ نو ځکه am ته اړتیا نشته او باید ولیکل شي: I agree.",
                    reasonEn = "'Agree' is a verb, not an adjective. Say 'I agree', not 'I am agree'."
                )
            )
            corrected = corrected.replace(Regex("(?i)\\bi am agree\\b"), "I agree")
        }

        // Rule 3: Third person singular - "he go" -> "he goes", "she go" -> "she goes"
        if (Regex("(?i)\\b(he|she)\\s+go\\b").containsMatchIn(corrected)) {
            issues.add(
                WritingIssue(
                    snippet = "he/she go",
                    correction = "he/she goes",
                    ruleType = "Subject-Verb Concord",
                    reasonDari = "در زمان حال ساده برای سوم شخص مفرد (He/She) به آخر فعل s یا es اضافه می‌شود.",
                    reasonPashto = "په ساده اوسمهال کې د مفرد غایب لپاره د فعل په پای کې s یا es زیاتیږي.",
                    reasonEn = "Third person singular subjects take -es with 'go': 'goes'."
                )
            )
            corrected = corrected.replace(Regex("(?i)\\bhe\\s+go\\b"), "he goes")
                .replace(Regex("(?i)\\bshe\\s+go\\b"), "she goes")
        }

        // Rule 4: "in the night" -> "at night"
        if (Regex("(?i)\\bin the night\\b").containsMatchIn(corrected)) {
            issues.add(
                WritingIssue(
                    snippet = "in the night",
                    correction = "at night",
                    ruleType = "Preposition Collocation",
                    reasonDari = "برای صبح و بعدازظهر می‌گوییم 'in the morning / in the afternoon'، اما برای شب معمولاً 'at night' استفاده می‌شود.",
                    reasonPashto = "د سهار لپاره 'in the morning' وایو، خو د شپې لپاره معمولاً د 'at night' اصطلاح کاریږي.",
                    reasonEn = "Standard English collocation for nighttime is 'at night'."
                )
            )
            corrected = corrected.replace(Regex("(?i)\\bin the night\\b"), "at night")
        }

        // Rule 5: Double negatives like "don't have no" -> "don't have any"
        if (Regex("(?i)\\bdon't have no\\b").containsMatchIn(corrected)) {
            issues.add(
                WritingIssue(
                    snippet = "don't have no",
                    correction = "don't have any",
                    ruleType = "Double Negative",
                    reasonDari = "در انگلیسی استاندارد از دو منفی‌کننده همزمان در یک جمله پرهیز کنید.",
                    reasonPashto = "په معیاري انګلیسي کې په یوه جمله کې د دوو منفي کلمو کارول ناسم دي.",
                    reasonEn = "Avoid double negatives in formal English. Use 'don't have any'."
                )
            )
            corrected = corrected.replace(Regex("(?i)\\bdon't have no\\b"), "don't have any")
        }

        // Punctuation check at the end
        if (!corrected.endsWith(".") && !corrected.endsWith("!") && !corrected.endsWith("?")) {
            corrected += "."
        }

        val wordCount = trimmed.split(Regex("\\s+")).size
        val baseScore = 95 - (issues.size * 12)
        val finalScore = baseScore.coerceIn(40, 100)
        val grammarScore = (finalScore - (issues.size * 5)).coerceIn(35, 100)
        val vocabScore = (finalScore + (wordCount.coerceAtMost(30) / 2)).coerceIn(45, 100)
        val coherenceScore = (finalScore + 5).coerceIn(45, 100)

        val remarksDari = if (issues.isEmpty()) {
            "نگارش بسیار تمیز، منسجم و بدون خطای ساختاری. سبک کلام شما زیبا و طبیعی است!"
        } else {
            "تلاش بسیار ارزشمندی بود! ${issues.size} نکته گرامری برای ارتقای نگارش شما اصلاح شد. لطفاً به دلایل آن توجه کنید."
        }

        val remarksPashto = if (issues.isEmpty()) {
            "خورا پاکه، منظمه او له تیروتنو پرته لیکنه. ستاسو طرز بیان طبیعي او خورا ښکلی دی!"
        } else {
            "ډیره ښه هڅه وه! ${issues.size} ګرامري ټکي د لیکنې د ښه کولو لپاره سم شول. مهرباني وکړئ دلایلو ته یې پام وکړئ."
        }

        val remarksEn = if (issues.isEmpty()) {
            "Splendid composition! Your grammar, tone, and punctuation are wonderfully aligned."
        } else {
            "Great effort! We polished ${issues.size} details to elevate your style to native standards."
        }

        return WritingCorrection(
            originalText = trimmed,
            correctedText = corrected,
            score = finalScore,
            grammarScore = grammarScore,
            vocabScore = vocabScore,
            coherenceScore = coherenceScore,
            issuesFound = issues,
            overallRemarksDari = remarksDari,
            overallRemarksPashto = remarksPashto,
            overallRemarksEn = remarksEn
        )
    }
}
