package com.example.ui.components

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.PopcornAmber
import com.example.ui.theme.PopcornBorder
import com.example.ui.theme.PopcornCream
import com.example.ui.theme.PopcornDarkShadow
import com.example.ui.theme.PopcornGold
import com.example.ui.theme.PopcornShadow
import com.example.ui.theme.PopcornSurface
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

/**
 * Soft 3D Popcorn-style Glass Card with gentle pillowy corners,
 * dual tactile borders, and soft ambient glow.
 */
@Composable
fun LuxuryGlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    borderColor: Color = PopcornBorder.copy(alpha = 0.5f),
    backgroundColor: Color = PopcornSurface.copy(alpha = 0.92f),
    content: @Composable ColumnScope.() -> Unit
) {
    Box(modifier = modifier.fillMaxWidth()) {
        // Soft bottom 3D shadow lip for tactile extrusion
        Box(
            modifier = Modifier
                .matchParentSize()
                .offset(y = 4.dp)
                .clip(RoundedCornerShape(cornerRadius))
                .background(PopcornDarkShadow.copy(alpha = 0.7f))
        )

        // Main puffy card surface with gentle border
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    BorderStroke(
                        width = 1.5.dp,
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                PopcornBorder.copy(alpha = 0.8f),
                                borderColor,
                                DarkBorder.copy(alpha = 0.6f)
                            )
                        )
                    ),
                    shape = RoundedCornerShape(cornerRadius)
                ),
            shape = RoundedCornerShape(cornerRadius),
            colors = CardDefaults.cardColors(containerColor = backgroundColor),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                content = content
            )
        }
    }
}

/**
 * 3D Extruded "Popcorn" Button with pillowy roundness, tactile protrusion (بیرون‌زدگی),
 * soft buttery gradient, highlighted dual borders, and spring press animation.
 */
@Composable
fun GoldButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    testTag: String = "gold_button"
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // 3D tactile press animation: pushes down towards the base when pressed
    val pushOffset by animateDpAsState(
        targetValue = if (isPressed) 4.dp else 0.dp,
        animationSpec = spring(stiffness = 800f),
        label = "popcorn_press"
    )

    val shape = RoundedCornerShape(28.dp)

    Box(
        modifier = modifier
            .height(58.dp)
            .testTag(testTag)
    ) {
        // 1. Bottom 3D Protrusion Lip (The Extruded Popcorn Base)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(53.dp)
                .offset(y = 5.dp)
                .clip(shape)
                .background(if (enabled) PopcornShadow else DarkBorder)
        )

        // 2. Puffy Top Popcorn Cap (Tender buttery gold with soft highlight border)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(53.dp)
                .offset(y = pushOffset)
                .clip(shape)
                .background(
                    if (enabled) {
                        Brush.verticalGradient(
                            listOf(
                                PopcornCream,
                                PopcornGold,
                                PopcornAmber
                            )
                        )
                    } else {
                        Brush.verticalGradient(listOf(DarkSurfaceElevated, DarkBorder))
                    }
                )
                .border(
                    BorderStroke(
                        width = 2.dp,
                        brush = Brush.verticalGradient(
                            listOf(
                                Color.White.copy(alpha = 0.9f),
                                PopcornBorder,
                                PopcornAmber.copy(alpha = 0.5f)
                            )
                        )
                    ),
                    shape = shape
                )
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    enabled = enabled,
                    onClick = onClick
                ),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.padding(horizontal = 20.dp)
            ) {
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (enabled) ObsidianBlack else Color.Gray,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                }
                Text(
                    text = text,
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.5.sp,
                        letterSpacing = 0.3.sp,
                        color = if (enabled) ObsidianBlack else Color.Gray
                    )
                )
            }
        }
    }
}

/**
 * Soft Tactile 3D Circular Button with popped-out protrusion
 * (for Audio play, voice record, slow speech, action buttons)
 */
@Composable
fun PopcornCircleButton(
    icon: ImageVector,
    onClick: () -> Unit,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    isActive: Boolean = false,
    size: Dp = 48.dp
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val pushOffset by animateDpAsState(
        targetValue = if (isPressed) 3.dp else 0.dp,
        label = "circle_popcorn_press"
    )

    Box(
        modifier = modifier.size(size + 4.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        // Bottom 3D shadow extrusion
        Box(
            modifier = Modifier
                .size(size)
                .offset(y = 4.dp)
                .clip(CircleShape)
                .background(if (isActive) PopcornShadow else DarkBorder)
        )

        // Puffy Top Button Cap
        Box(
            modifier = Modifier
                .size(size)
                .offset(y = pushOffset)
                .clip(CircleShape)
                .background(
                    if (isActive) {
                        Brush.verticalGradient(listOf(PopcornCream, PopcornGold, PopcornAmber))
                    } else {
                        Brush.verticalGradient(listOf(DarkSurfaceCard, DarkSurfaceElevated))
                    }
                )
                .border(
                    BorderStroke(
                        width = 1.8.dp,
                        brush = Brush.verticalGradient(
                            listOf(
                                if (isActive) Color.White else PopcornBorder.copy(alpha = 0.5f),
                                if (isActive) PopcornBorder else GlowGold
                            )
                        )
                    ),
                    shape = CircleShape
                )
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onClick
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = if (isActive) ObsidianBlack else LuxuryGold,
                modifier = Modifier.size(size * 0.48f)
            )
        }
    }
}

/**
 * Avatar for Teacher Gohari (استاد گوهری)
 * Featuring gentle 3D claymorphic portrait, soft glowing pearl ring, and active status.
 */
@Composable
fun ZahraAvatarView(
    size: Dp = 68.dp,
    showActiveBadge: Boolean = true,
    modifier: Modifier = Modifier
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier.size(size + 12.dp)
    ) {
        // Soft Tactile 3D Extrusion Shadow behind Avatar
        Box(
            modifier = Modifier
                .size(size + 8.dp)
                .offset(y = 3.dp)
                .clip(CircleShape)
                .background(PopcornShadow.copy(alpha = 0.6f))
        )

        // Glowing Golden & Pearl Ring
        Box(
            modifier = Modifier
                .size(size + 8.dp)
                .clip(CircleShape)
                .background(
                    Brush.sweepGradient(
                        listOf(PopcornCream, LuxuryGold, WarmGold, PopcornBorder, PopcornCream)
                    )
                )
                .border(1.5.dp, PopcornBorder, CircleShape)
        )

        // Avatar Image of Teacher Gohari
        AsyncImage(
            model = R.drawable.teacher_gohari,
            contentDescription = "Teacher Gohari Avatar",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .border(2.dp, ObsidianBlack, CircleShape)
        )

        if (showActiveBadge) {
            Box(
                modifier = Modifier
                    .size(18.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = (-2).dp, y = (-2).dp)
                    .clip(CircleShape)
                    .background(EmeraldGreen)
                    .border(2.5.dp, ObsidianBlack, CircleShape)
            )
        }
    }
}

@Composable
fun AudioPlayButton(
    isSpeaking: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isSlow: Boolean = false
) {
    PopcornCircleButton(
        icon = if (isSpeaking) Icons.Default.GraphicEq else Icons.Default.VolumeUp,
        contentDescription = if (isSlow) "Slow audio playback" else "Audio playback",
        onClick = onClick,
        isActive = isSpeaking,
        modifier = modifier,
        size = 46.dp
    )
}

/**
 * Puffy Pill Badge with soft popcorn highlight
 */
@Composable
fun LevelBadge(
    levelCode: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = PopcornGold.copy(alpha = 0.18f),
        border = BorderStroke(1.5.dp, PopcornBorder.copy(alpha = 0.7f)),
        modifier = modifier
    ) {
        Text(
            text = levelCode,
            color = PopcornGold,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 4.dp),
            textAlign = TextAlign.Center
        )
    }
}

/**
 * 3D Tactile "Popcorn" Selectable Option Card with outward protrusion lip,
 * pillowy curvature, soft buttery highlight border, and responsive press feedback.
 */
@Composable
fun PopcornSelectableOption(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isCorrect: Boolean? = null,
    prefixNumber: Int? = null
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val pushOffset by animateDpAsState(
        targetValue = if (isPressed) 3.dp else 0.dp,
        animationSpec = spring(stiffness = 900f),
        label = "popcorn_opt_press"
    )

    val shape = RoundedCornerShape(20.dp)

    val capGradient = when {
        isCorrect == true -> Brush.verticalGradient(listOf(Color(0xFF2ECC71), Color(0xFF27AE60)))
        isCorrect == false -> Brush.verticalGradient(listOf(Color(0xFFE74C3C), Color(0xFFC0392B)))
        isSelected -> Brush.verticalGradient(listOf(PopcornCream, PopcornGold, PopcornAmber))
        else -> Brush.verticalGradient(listOf(DarkSurfaceElevated, DarkSurfaceCard))
    }

    val shadowColor = when {
        isCorrect == true -> Color(0xFF1E8449)
        isCorrect == false -> Color(0xFF922B21)
        isSelected -> PopcornShadow
        else -> DarkBorder
    }

    val borderColor = when {
        isCorrect == true -> Color.White.copy(alpha = 0.8f)
        isCorrect == false -> Color.White.copy(alpha = 0.7f)
        isSelected -> PopcornBorder
        else -> DarkBorder.copy(alpha = 0.8f)
    }

    val contentColor = when {
        isCorrect == true || isCorrect == false -> Color.White
        isSelected -> ObsidianBlack
        else -> MaterialTheme.colorScheme.onSurface
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        // 3D Extruded Bottom Shadow Lip
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .offset(y = 4.dp)
                .clip(shape)
                .background(shadowColor)
        )

        // Puffy Top Option Cap
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .offset(y = pushOffset)
                .clip(shape)
                .background(capGradient)
                .border(
                    BorderStroke(
                        width = if (isSelected || isCorrect != null) 2.dp else 1.2.dp,
                        color = borderColor
                    ),
                    shape = shape
                )
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    enabled = enabled,
                    onClick = onClick
                ),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (prefixNumber != null) "$prefixNumber.  $text" else text,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = if (isSelected || isCorrect != null) FontWeight.ExtraBold else FontWeight.Medium,
                        fontSize = 15.sp,
                        color = contentColor
                    )
                )

                if (isCorrect == true) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Correct",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                } else if (isCorrect == false) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Incorrect",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

/**
 * 3D Popcorn Pill Tab for horizontal selectors (Lessons, levels, topics)
 */
@Composable
fun PopcornPillTab(
    title: String,
    badge: String?,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val pushOffset by animateDpAsState(
        targetValue = if (isPressed) 2.dp else 0.dp,
        label = "tab_press"
    )

    val shape = RoundedCornerShape(16.dp)

    Box(
        modifier = modifier.padding(vertical = 4.dp)
    ) {
        // Shadow base
        Box(
            modifier = Modifier
                .offset(y = 3.dp)
                .clip(shape)
                .background(if (isSelected) PopcornShadow else DarkBorder)
        )

        // Pill cap
        Surface(
            shape = shape,
            color = if (isSelected) PopcornGold else DarkSurfaceElevated,
            border = BorderStroke(1.5.dp, if (isSelected) PopcornBorder else GlowGold.copy(alpha = 0.4f)),
            modifier = Modifier
                .offset(y = pushOffset)
                .clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onClick
                )
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
            ) {
                if (badge != null) {
                    Text(
                        text = badge,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isSelected) ObsidianBlack else PopcornGold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text(
                    text = title,
                    fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                    color = if (isSelected) ObsidianBlack else MaterialTheme.colorScheme.onSurface,
                    fontSize = 13.sp
                )
            }
        }
    }
}
