package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Language
import com.example.localization.Strings
import com.example.ui.MainViewModel
import com.example.ui.components.GoldButton
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

@Composable
fun SettingsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val profile by viewModel.userProfile.collectAsState()

    var voicePitch by remember(profile) { mutableFloatStateOf(profile?.voicePitch ?: 1.15f) }
    var speechSpeed by remember(profile) { mutableFloatStateOf(profile?.speechSpeed ?: 0.95f) }
    var isUSAccent by remember(profile) { mutableStateOf(profile?.isAccentUS ?: true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Language Selection Card
        item {
            LuxuryGlassCard(
                modifier = Modifier.testTag("settings_lang_card"),
                borderColor = LuxuryGold
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Translate, contentDescription = null, tint = LuxuryGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "زبان رابط کاربری (Interface Language):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = LuxuryGold
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "موضوع آموزش منحصراً زبان انگلیسی است. زبان انتخابی فقط برای توضیحات و ارتباط با استاد زهرا به کار می‌رود.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                Language.entries.forEach { item ->
                    val isSelected = item == lang
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) LuxuryGold.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) LuxuryGold else DarkBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { viewModel.setLanguage(item) }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(12.dp)
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { viewModel.setLanguage(item) },
                                colors = RadioButtonDefaults.colors(selectedColor = LuxuryGold)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = item.titleInSelf,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isSelected) LuxuryGold else MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = item.englishName,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Theme Switcher Card
        item {
            LuxuryGlassCard(borderColor = GlowGold) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (profile?.isDarkTheme != false) Icons.Default.DarkMode else Icons.Default.LightMode,
                            contentDescription = null,
                            tint = LuxuryGold
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "تم مشکی و طلایی لوکس (Dark Theme)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (profile?.isDarkTheme != false) "تم تیره سلطنتی فعال است" else "تم روشن فعال است",
                                fontSize = 12.sp,
                                color = SoftGold
                            )
                        }
                    }

                    Switch(
                        checked = profile?.isDarkTheme ?: true,
                        onCheckedChange = { viewModel.toggleTheme() },
                        colors = SwitchDefaults.colors(checkedThumbColor = LuxuryGold, checkedTrackColor = LuxuryGold.copy(alpha = 0.3f))
                    )
                }
            }
        }

        // Voice Engine & Accent Card
        item {
            LuxuryGlassCard(borderColor = GlowGold) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = LuxuryGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "تنظیمات صدای زنانه استاد گوهری:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = LuxuryGold
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Accent Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "لهجه گفتار: ${if (isUSAccent) "آمریکایی (American US)" else "بریتانیایی (British UK)"}",
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Switch(
                        checked = isUSAccent,
                        onCheckedChange = {
                            isUSAccent = it
                            viewModel.updateVoiceConfig(voicePitch, speechSpeed, isUSAccent)
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = LuxuryGold)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Pitch Slider
                Text(
                    text = "تن صدای زنانه (Pitch): ${String.format("%.2f", voicePitch)}x",
                    fontSize = 13.sp,
                    color = SoftGold
                )
                Slider(
                    value = voicePitch,
                    onValueChange = {
                        voicePitch = it
                        viewModel.updateVoiceConfig(voicePitch, speechSpeed, isUSAccent)
                    },
                    valueRange = 0.9f..1.4f,
                    colors = SliderDefaults.colors(thumbColor = LuxuryGold, activeTrackColor = LuxuryGold)
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Speed Slider
                Text(
                    text = "سرعت گفتار (Speed): ${String.format("%.2f", speechSpeed)}x",
                    fontSize = 13.sp,
                    color = SoftGold
                )
                Slider(
                    value = speechSpeed,
                    onValueChange = {
                        speechSpeed = it
                        viewModel.updateVoiceConfig(voicePitch, speechSpeed, isUSAccent)
                    },
                    valueRange = 0.6f..1.3f,
                    colors = SliderDefaults.colors(thumbColor = LuxuryGold, activeTrackColor = LuxuryGold)
                )

                Spacer(modifier = Modifier.height(10.dp))

                GoldButton(
                    text = "آزمایش صدای استاد گوهری",
                    icon = Icons.Default.GraphicEq,
                    onClick = {
                        viewModel.speak(Strings.reminderVoiceMessage(lang))
                    },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // Offline Guarantee & Database Storage Info
        item {
            LuxuryGlassCard(borderColor = EmeraldGreen.copy(alpha = 0.4f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Storage, contentDescription = null, tint = EmeraldGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "معماری کاملاً آفلاین و امنیت داده‌ها:",
                        fontWeight = FontWeight.Bold,
                        color = EmeraldGreen,
                        fontSize = 15.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• وضعیت اتصال: کاملاً آفلاین و مستقل از اینترنت\n• پایگاه داده: Room Database محلی روی حافظه گوشی\n• پردازش صوت: موتور TextToSpeech محلی اندروید\n• حریم خصوصی: تمام سوابق، نمرات و صداها درون دستگاه شما محفوظ می‌مانند.",
                    fontSize = 12.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 22.sp
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
