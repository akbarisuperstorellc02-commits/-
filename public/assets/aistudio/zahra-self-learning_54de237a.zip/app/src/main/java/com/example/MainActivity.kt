package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.FontDownload
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Language
import com.example.localization.Strings
import com.example.ui.AppScreen
import com.example.ui.MainViewModel
import com.example.ui.components.LevelBadge
import com.example.ui.components.ZahraAvatarView
import com.example.ui.screens.AlphabetPhonicsScreen
import com.example.ui.screens.AssessmentScreen
import com.example.ui.screens.CurriculumPathScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.GrammarScreen
import com.example.ui.screens.ScheduleScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StoriesScreen
import com.example.ui.screens.TeacherChatScreen
import com.example.ui.screens.VocabularyScreen
import com.example.ui.screens.WritingLabScreen
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold
import com.example.ui.theme.ZahraTheme

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Handle intent from Alarm notification if user clicked "Start Lesson"
        intent?.getStringExtra("OPEN_SCREEN")?.let { target ->
            if (target == "TEACHER_CHAT") {
                viewModel.navigateTo(AppScreen.TEACHER_CHAT)
            }
        }

        setContent {
            val profile by viewModel.userProfile.collectAsState()
            val isDark = profile?.isDarkTheme ?: true
            val currentLanguage by viewModel.currentLanguage.collectAsState()

            ZahraTheme(darkTheme = isDark) {
                // Direction Provider: RTL for Dari & Pashto, LTR for English
                val layoutDirection = if (currentLanguage.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

                CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                    MainAppScaffold(viewModel = viewModel)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScaffold(viewModel: MainViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val lang by viewModel.currentLanguage.collectAsState()
    val profile by viewModel.userProfile.collectAsState()

    // Android Hardware / Gesture BackHandler
    BackHandler(enabled = currentScreen != AppScreen.DASHBOARD) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.safeDrawing),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { viewModel.navigateTo(AppScreen.DASHBOARD) }
                    ) {
                        ZahraAvatarView(size = 36.dp, showActiveBadge = false)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = Strings.appTitle(lang),
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = LuxuryGold,
                                    fontSize = 17.sp
                                )
                            )
                            Text(
                                text = "100% Offline • AI Academy",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = SoftGold,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                },
                actions = {
                    // Quick Language Switcher Pill
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, GlowGold),
                        modifier = Modifier.clickable {
                            // Cycle through Dari -> Pashto -> English -> Dari
                            val nextLang = when (lang) {
                                Language.DARI -> Language.PASHTO
                                Language.PASHTO -> Language.ENGLISH
                                Language.ENGLISH -> Language.DARI
                            }
                            viewModel.setLanguage(nextLang)
                        }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Translate,
                                contentDescription = "Language",
                                tint = LuxuryGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = when (lang) {
                                    Language.DARI -> "دری"
                                    Language.PASHTO -> "پښتو"
                                    Language.ENGLISH -> "EN"
                                },
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = LuxuryGold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Settings Button
                    IconButton(
                        onClick = { viewModel.navigateTo(AppScreen.SETTINGS) },
                        modifier = Modifier.testTag("top_bar_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = if (currentScreen == AppScreen.SETTINGS) LuxuryGold else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .border(
                        androidx.compose.foundation.BorderStroke(1.dp, GlowGold.copy(alpha = 0.3f)),
                        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                    )
            ) {
                // Dashboard
                NavigationBarItem(
                    selected = currentScreen == AppScreen.DASHBOARD,
                    onClick = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                    label = { Text(Strings.navDashboard(lang), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBlack,
                        selectedTextColor = LuxuryGold,
                        indicatorColor = LuxuryGold,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )

                // Teacher Chat
                NavigationBarItem(
                    selected = currentScreen == AppScreen.TEACHER_CHAT,
                    onClick = { viewModel.navigateTo(AppScreen.TEACHER_CHAT) },
                    icon = { Icon(Icons.Default.Chat, contentDescription = null) },
                    label = { Text(Strings.navTeacher(lang), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBlack,
                        selectedTextColor = LuxuryGold,
                        indicatorColor = LuxuryGold,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )

                // Path / Curriculum
                NavigationBarItem(
                    selected = currentScreen == AppScreen.CURRICULUM_PATH,
                    onClick = { viewModel.navigateTo(AppScreen.CURRICULUM_PATH) },
                    icon = { Icon(Icons.Default.Stars, contentDescription = null) },
                    label = { Text(Strings.navPath(lang), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBlack,
                        selectedTextColor = LuxuryGold,
                        indicatorColor = LuxuryGold,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )

                // Alphabet / Phonics
                NavigationBarItem(
                    selected = currentScreen == AppScreen.ALPHABET_PHONICS,
                    onClick = { viewModel.navigateTo(AppScreen.ALPHABET_PHONICS) },
                    icon = { Icon(Icons.Default.FontDownload, contentDescription = null) },
                    label = { Text("الفبا", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBlack,
                        selectedTextColor = LuxuryGold,
                        indicatorColor = LuxuryGold,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )

                // Schedule & Alarms
                NavigationBarItem(
                    selected = currentScreen == AppScreen.DAILY_SCHEDULE,
                    onClick = { viewModel.navigateTo(AppScreen.DAILY_SCHEDULE) },
                    icon = { Icon(Icons.Default.Alarm, contentDescription = null) },
                    label = { Text(Strings.navSchedule(lang), fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = ObsidianBlack,
                        selectedTextColor = LuxuryGold,
                        indicatorColor = LuxuryGold,
                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = { fadeIn() togetherWith fadeOut() },
            label = "screen_transition",
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) { targetScreen ->
            when (targetScreen) {
                AppScreen.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                AppScreen.TEACHER_CHAT -> TeacherChatScreen(viewModel = viewModel)
                AppScreen.CURRICULUM_PATH -> CurriculumPathScreen(viewModel = viewModel)
                AppScreen.ALPHABET_PHONICS -> AlphabetPhonicsScreen(viewModel = viewModel)
                AppScreen.VOCABULARY_SRS -> VocabularyScreen(viewModel = viewModel)
                AppScreen.GRAMMAR_ACADEMY -> GrammarScreen(viewModel = viewModel)
                AppScreen.STORIES_LIBRARY -> StoriesScreen(viewModel = viewModel)
                AppScreen.WRITING_LAB -> WritingLabScreen(viewModel = viewModel)
                AppScreen.ASSESSMENT_REPORT -> AssessmentScreen(viewModel = viewModel)
                AppScreen.DAILY_SCHEDULE -> ScheduleScreen(viewModel = viewModel)
                AppScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
                AppScreen.FOUR_SKILLS -> AlphabetPhonicsScreen(viewModel = viewModel)
            }
        }
    }
}
