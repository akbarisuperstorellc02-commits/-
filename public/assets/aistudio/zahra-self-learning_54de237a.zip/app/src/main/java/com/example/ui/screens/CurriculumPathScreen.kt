package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LearningLevel
import com.example.localization.Language
import com.example.localization.Strings
import com.example.ui.AppScreen
import com.example.ui.MainViewModel
import com.example.ui.components.LevelBadge
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

@Composable
fun CurriculumPathScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val profile by viewModel.userProfile.collectAsState()
    val currentLevelCode = profile?.currentLevelCode ?: "A0"

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        item {
            LuxuryGlassCard(
                modifier = Modifier.testTag("curriculum_hero_card"),
                borderColor = LuxuryGold
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Stars,
                        contentDescription = null,
                        tint = LuxuryGold,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "نقشه جامع یادگیری: از صفر مطلق تا فراتر از C2",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp,
                        color = LuxuryGold
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "مسیر آموزشی زهرا در C2 متوقف نمی‌شود؛ بلکه به دوره‌های تخصصی دانشگاهی، حقوقی، تجاری، پزشکی و هوش مصنوعی Post-C2 امتداد می‌یابد.",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                )
            }
        }

        // Full Roadmap from A0 to Post-C2
        items(LearningLevel.entries) { level ->
            val isCurrent = level.code == currentLevelCode
            val isCompleted = level.order < (LearningLevel.entries.firstOrNull { it.code == currentLevelCode }?.order ?: 0)

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isCurrent) LuxuryGold.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isCurrent) LuxuryGold else if (isCompleted) EmeraldGreen else DarkBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.setLevel(level)
                        when (level) {
                            LearningLevel.A0, LearningLevel.PRE_A1 -> viewModel.navigateTo(AppScreen.ALPHABET_PHONICS)
                            LearningLevel.A1, LearningLevel.A2 -> viewModel.navigateTo(AppScreen.VOCABULARY_SRS)
                            LearningLevel.B1, LearningLevel.B2 -> viewModel.navigateTo(AppScreen.GRAMMAR_ACADEMY)
                            LearningLevel.C1, LearningLevel.C2 -> viewModel.navigateTo(AppScreen.STORIES_LIBRARY)
                            LearningLevel.POST_C2 -> viewModel.navigateTo(AppScreen.WRITING_LAB)
                        }
                    }
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Level Badge / Step Circle
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCurrent) LuxuryGold else if (isCompleted) EmeraldGreen else MaterialTheme.colorScheme.surface
                            )
                            .border(1.dp, if (isCurrent) LuxuryGold else GlowGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ObsidianBlack)
                        } else {
                            Text(
                                text = level.code,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp,
                                color = if (isCurrent) ObsidianBlack else LuxuryGold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = level.localizedTitle(lang),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            if (isCurrent) {
                                Spacer(modifier = Modifier.width(6.dp))
                                LevelBadge(levelCode = "سطح شما")
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = level.localizedDesc(lang),
                            fontSize = 12.5.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )
                    }

                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Go to lessons",
                        tint = if (isCurrent) LuxuryGold else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
