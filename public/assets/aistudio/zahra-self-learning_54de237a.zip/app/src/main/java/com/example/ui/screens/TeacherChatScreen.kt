package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessage
import com.example.data.model.ConversationScenario
import com.example.localization.Language
import com.example.ui.MainViewModel
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.components.PopcornCircleButton
import com.example.ui.components.ZahraAvatarView
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

@Composable
fun TeacherChatScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val activeScenario by viewModel.activeScenario.collectAsState()
    val scenarios = viewModel.scenariosList
    val messages by viewModel.chatMessages.collectAsState()

    var inputMessage by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Auto-scroll when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(4.dp))

        // Scenario Picker Horizontal Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(vertical = 4.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(scenarios) { scenario ->
                val isSelected = scenario.id == activeScenario.id
                val title = when (lang) {
                    Language.DARI -> scenario.titleDari
                    Language.PASHTO -> scenario.titlePashto
                    Language.ENGLISH -> scenario.titleEn
                }

                com.example.ui.components.PopcornPillTab(
                    title = title,
                    badge = null,
                    isSelected = isSelected,
                    onClick = { viewModel.selectScenario(scenario) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Chat Messages Thread
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages) { msg ->
                ChatMessageItem(
                    message = msg,
                    userLang = lang,
                    onSpeak = { text, slow -> viewModel.speak(text, slow) }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Suggested Responses from Zahra
        if (activeScenario.suggestedUserResponses.isNotEmpty()) {
            Text(
                text = "پیشنهادهای مکالمه (Suggested Responses):",
                style = MaterialTheme.typography.labelSmall.copy(color = SoftGold)
            )
            Spacer(modifier = Modifier.height(4.dp))
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(activeScenario.suggestedUserResponses) { suggestion ->
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(DarkSurfaceElevated)
                            .border(1.dp, GlowGold, RoundedCornerShape(10.dp))
                            .clickable {
                                inputMessage = suggestion
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = suggestion,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        // Bottom Input Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputMessage,
                onValueChange = { inputMessage = it },
                placeholder = { Text("Speak or type in English...") },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field"),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = LuxuryGold,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                ),
                maxLines = 3
            )

            Spacer(modifier = Modifier.width(8.dp))

            PopcornCircleButton(
                icon = Icons.Default.Send,
                contentDescription = "Send",
                onClick = {
                    if (inputMessage.isNotBlank()) {
                        viewModel.sendUserMessage(inputMessage)
                        inputMessage = ""
                    }
                },
                isActive = true,
                size = 52.dp,
                modifier = Modifier.testTag("chat_send_button")
            )
        }
    }
}

@Composable
private fun ChatMessageItem(
    message: ChatMessage,
    userLang: Language,
    onSpeak: (String, Boolean) -> Unit
) {
    var showTranslation by remember { mutableStateOf(false) }

    if (message.isFromTeacher) {
        // Teacher Zahra Bubble
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start
        ) {
            ZahraAvatarView(size = 38.dp, showActiveBadge = false)

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f, fill = false)) {
                Card(
                    shape = RoundedCornerShape(18.dp).copy(topStart = androidx.compose.foundation.shape.CornerSize(4.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlowGold.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = message.text,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.5.sp,
                                lineHeight = 22.sp
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Listen Audio 3D Popcorn Button
                            PopcornCircleButton(
                                icon = Icons.Default.VolumeUp,
                                contentDescription = "Listen to Teacher Gohari",
                                onClick = { onSpeak(message.text, false) },
                                size = 36.dp
                            )

                            // Slow Audio 3D Popcorn Button
                            PopcornCircleButton(
                                icon = Icons.Default.Speed,
                                contentDescription = "Listen slow",
                                onClick = { onSpeak(message.text, true) },
                                size = 36.dp
                            )

                            // Toggle Translation in Dari/Pashto
                            val translation = when (userLang) {
                                Language.DARI -> message.translationDari
                                Language.PASHTO -> message.translationPashto
                                Language.ENGLISH -> null
                            }

                            if (!translation.isNullOrEmpty()) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = LuxuryGold.copy(alpha = 0.12f),
                                    modifier = Modifier.clickable { showTranslation = !showTranslation }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Translate,
                                            contentDescription = null,
                                            tint = LuxuryGold,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (showTranslation) "بستن ترجمه" else "ترجمه فارسی / پشتو",
                                            fontSize = 11.sp,
                                            color = SoftGold
                                        )
                                    }
                                }
                            }
                        }

                        if (showTranslation) {
                            val translation = when (userLang) {
                                Language.DARI -> message.translationDari
                                Language.PASHTO -> message.translationPashto
                                Language.ENGLISH -> null
                            }
                            if (!translation.isNullOrEmpty()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(DarkSurfaceElevated)
                                        .padding(8.dp)
                                ) {
                                    Text(
                                        text = translation,
                                        fontSize = 13.sp,
                                        color = SoftGold,
                                        lineHeight = 20.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        // User Message Bubble
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Card(
                shape = RoundedCornerShape(18.dp).copy(topEnd = androidx.compose.foundation.shape.CornerSize(4.dp)),
                colors = CardDefaults.cardColors(containerColor = LuxuryGold),
                modifier = Modifier.padding(start = 48.dp)
            ) {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = ObsidianBlack,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.5.sp
                    ),
                    modifier = Modifier.padding(14.dp)
                )
            }
        }
    }
}
