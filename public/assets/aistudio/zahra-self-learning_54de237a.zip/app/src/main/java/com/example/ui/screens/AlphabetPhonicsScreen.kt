package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AlphabetLetter
import com.example.localization.Language
import com.example.localization.Strings
import com.example.ui.MainViewModel
import com.example.ui.components.GoldButton
import com.example.ui.components.PopcornCircleButton
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

@Composable
fun AlphabetPhonicsScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val selectedIndex by viewModel.selectedLetterIndex.collectAsState()
    val letters = viewModel.alphabetList
    val currentLetter = letters[selectedIndex]
    val evaluation by viewModel.pronunciationResult.collectAsState()

    var activeTab by remember { mutableIntStateOf(0) }
    var userSpokenAttempt by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Tabs: 26 Letters vs Blends & Digraphs
        item {
            ScrollableTabRow(
                selectedTabIndex = activeTab,
                containerColor = Color.Transparent,
                edgePadding = 0.dp,
                divider = {},
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[activeTab]),
                        color = LuxuryGold,
                        height = 3.dp
                    )
                }
            ) {
                Tab(
                    selected = activeTab == 0,
                    onClick = { activeTab = 0 },
                    text = {
                        Text(
                            text = "26 English Letters (A - Z)",
                            fontWeight = if (activeTab == 0) FontWeight.Bold else FontWeight.Normal,
                            color = if (activeTab == 0) LuxuryGold else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                )
                Tab(
                    selected = activeTab == 1,
                    onClick = { activeTab = 1 },
                    text = {
                        Text(
                            text = "Phonics Blends & Digraphs",
                            fontWeight = if (activeTab == 1) FontWeight.Bold else FontWeight.Normal,
                            color = if (activeTab == 1) LuxuryGold else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                )
            }
        }

        if (activeTab == 0) {
            // Horizontal Letter Selector Ribbon
            item {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    itemsIndexed(letters) { index, letter ->
                        val isSelected = index == selectedIndex
                        Box(
                            modifier = Modifier
                                .size(50.dp, 54.dp)
                                .padding(vertical = 2.dp)
                        ) {
                            // Bottom 3D shadow extrusion
                            Box(
                                modifier = Modifier
                                    .size(48.dp, 46.dp)
                                    .offset(y = 3.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(if (isSelected) com.example.ui.theme.PopcornShadow else DarkBorder)
                            )
                            // Puffy top letter cap
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(48.dp, 46.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(
                                        if (isSelected) androidx.compose.ui.graphics.Brush.verticalGradient(
                                            listOf(
                                                com.example.ui.theme.PopcornCream,
                                                com.example.ui.theme.PopcornGold,
                                                com.example.ui.theme.PopcornAmber
                                            )
                                        ) else androidx.compose.ui.graphics.Brush.verticalGradient(
                                            listOf(
                                                DarkSurfaceElevated,
                                                com.example.ui.theme.DarkSurfaceCard
                                            )
                                        )
                                    )
                                    .border(
                                        1.5.dp,
                                        if (isSelected) com.example.ui.theme.PopcornBorder else GlowGold.copy(alpha = 0.4f),
                                        RoundedCornerShape(14.dp)
                                    )
                                    .clickable {
                                        viewModel.selectLetter(index)
                                        userSpokenAttempt = ""
                                    }
                            ) {
                                Text(
                                    text = "${letter.letter}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 20.sp,
                                    color = if (isSelected) ObsidianBlack else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }

            // Big Showcase Card for the Selected Letter
            item {
                LuxuryGlassCard(
                    modifier = Modifier.testTag("letter_showcase_card"),
                    borderColor = LuxuryGold
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text(
                                    text = "${currentLetter.letter} ${currentLetter.lowerLetter}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 48.sp,
                                    color = LuxuryGold
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = currentLetter.ipa,
                                    fontSize = 20.sp,
                                    color = SoftGold,
                                    modifier = Modifier.padding(bottom = 8.dp)
                                )
                            }
                            Text(
                                text = if (currentLetter.isVowel) "Vowel (واکه / صدادار)" else "Consonant (همخوان / بی صدا)",
                                color = if (currentLetter.isVowel) EmeraldGreen else WarmGold,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        // 3D Popcorn Audio Buttons
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            PopcornCircleButton(
                                icon = Icons.Default.VolumeUp,
                                contentDescription = "Pronounce Letter",
                                onClick = {
                                    viewModel.speak("${currentLetter.letter}, ${currentLetter.exampleWord}")
                                },
                                size = 46.dp
                            )

                            PopcornCircleButton(
                                icon = Icons.Default.Speed,
                                contentDescription = "Slow Pronunciation",
                                onClick = {
                                    viewModel.speak("${currentLetter.letter}, ${currentLetter.exampleWord}", isSlow = true)
                                },
                                size = 46.dp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Example Word Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(DarkSurfaceElevated)
                            .border(1.dp, GlowGold, RoundedCornerShape(14.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = currentLetter.exampleWord,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 24.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = currentLetter.exampleIpa,
                                    fontSize = 15.sp,
                                    color = SoftGold
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                Text(
                                    text = "دری: ${currentLetter.exampleDari}",
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "پښتو: ${currentLetter.examplePashto}",
                                    fontSize = 14.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Teacher Zahra's Pronunciation Tip
                    val tip = when (lang) {
                        Language.DARI -> currentLetter.tipDari
                        Language.PASHTO -> currentLetter.tipPashto
                        Language.ENGLISH -> "Letter ${currentLetter.letter}: ${currentLetter.phoneticSound}. Focus on clear mouth articulation."
                    }
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(LuxuryGold.copy(alpha = 0.08f))
                            .border(1.dp, LuxuryGold.copy(alpha = 0.2f), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = "راهنمای استاد گوهری (Teacher Gohari's Phonics Guide):",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = LuxuryGold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = tip,
                                fontSize = 13.sp,
                                color = SoftGold,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
            }

            // Interactive Pronunciation Assessment Studio
            item {
                LuxuryGlassCard(
                    modifier = Modifier.testTag("pronunciation_tester_card"),
                    borderColor = WarmGold.copy(alpha = 0.4f)
                ) {
                    Text(
                        text = "ارزیابی تلفظ و تکرار صوتی (Pronunciation Studio)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = LuxuryGold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "کلمه «${currentLetter.exampleWord}» را تکرار کنید و تلفظ خود را بسنجید:",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = userSpokenAttempt,
                        onValueChange = { userSpokenAttempt = it },
                        placeholder = { Text("متن گفتاری یا تلفظ شما (مثلاً ${currentLetter.exampleWord})") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LuxuryGold,
                            unfocusedBorderColor = DarkBorder,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        GoldButton(
                            text = Strings.btnSubmit(lang),
                            onClick = {
                                val attempt = if (userSpokenAttempt.isBlank()) currentLetter.exampleWord else userSpokenAttempt
                                viewModel.evaluatePronunciation(currentLetter.exampleWord, attempt)
                            },
                            modifier = Modifier.weight(1f),
                            testTag = "btn_evaluate_pronunciation"
                        )

                        Button(
                            onClick = {
                                userSpokenAttempt = currentLetter.exampleWord
                                viewModel.speak(currentLetter.exampleWord)
                            },
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.height(52.dp)
                        ) {
                            Icon(Icons.Default.Mic, contentDescription = "Simulate voice")
                        }
                    }

                    // Evaluation Result Display
                    if (evaluation != null) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(DarkSurfaceElevated)
                                .border(
                                    1.dp,
                                    if (evaluation!!.score >= 75) EmeraldGreen else LuxuryGold,
                                    RoundedCornerShape(14.dp)
                                )
                                .padding(14.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "نمره تلفظ: ${evaluation!!.score}٪",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 18.sp,
                                        color = if (evaluation!!.score >= 75) EmeraldGreen else LuxuryGold
                                    )
                                    Text(
                                        text = evaluation!!.accuracy,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SoftGold
                                    )
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                val feedback = when (lang) {
                                    Language.DARI -> evaluation!!.feedbackDari
                                    Language.PASHTO -> evaluation!!.feedbackPashto
                                    Language.ENGLISH -> evaluation!!.feedbackEn
                                }
                                Text(
                                    text = feedback,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 20.sp
                                )
                            }
                        }
                    }
                }
            }

            // Navigation Next/Previous Letter Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = { viewModel.selectLetter(selectedIndex - 1) },
                        enabled = selectedIndex > 0,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(Strings.btnPrevious(lang))
                    }

                    Button(
                        onClick = { viewModel.selectLetter(selectedIndex + 1) },
                        enabled = selectedIndex < letters.size - 1,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(Strings.btnNext(lang))
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.ArrowForward, contentDescription = null)
                    }
                }
            }
        } else {
            // Phonics Blends & Digraphs Tab
            item {
                Text(
                    text = "ترکیب‌های آوایی و تلفظ‌های ویژه (Blends & Digraphs):",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = LuxuryGold
                    )
                )
            }

            itemsIndexed(viewModel.phonicsBlends) { _, blend ->
                LuxuryGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = GlowGold
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = blend.blend,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 26.sp,
                                    color = LuxuryGold
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = blend.ipa,
                                    fontSize = 16.sp,
                                    color = SoftGold
                                )
                            }
                            val desc = when (lang) {
                                Language.DARI -> blend.soundDescDari
                                Language.PASHTO -> blend.soundDescPashto
                                Language.ENGLISH -> blend.soundDesc
                            }
                            Text(
                                text = desc,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        PopcornCircleButton(
                            icon = Icons.Default.VolumeUp,
                            contentDescription = "Speak blend examples",
                            onClick = {
                                viewModel.speak(blend.exampleWords.joinToString(", "))
                            },
                            size = 42.dp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "مثال‌ها (Examples): ${blend.exampleWords.joinToString(" • ")}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
