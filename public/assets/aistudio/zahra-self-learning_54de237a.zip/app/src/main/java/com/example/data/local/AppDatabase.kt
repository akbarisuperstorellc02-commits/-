package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserProfileEntity::class,
        ScheduleEntity::class,
        VocabProgressEntity::class,
        MistakeEntity::class,
        AssessmentEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun vocabDao(): VocabDao
    abstract fun mistakeDao(): MistakeDao
    abstract fun assessmentDao(): AssessmentDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "zahra_academy.db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database)
                    }
                }
            }

            suspend fun populateInitialData(database: AppDatabase) {
                // Default Profile
                database.userDao().insertOrUpdate(
                    UserProfileEntity(
                        id = 1,
                        name = "زبان‌آموز گرامی",
                        selectedLanguageCode = "fa-AF",
                        isDarkTheme = true,
                        currentLevelCode = "A0",
                        targetGoal = "تسلط کامل و مکالمه سلیس",
                        streakDays = 3,
                        totalStudyMinutes = 45,
                        wordsLearned = 26,
                        voicePitch = 1.15f,
                        speechSpeed = 0.95f,
                        isAccentUS = true
                    )
                )

                // Default Daily Schedules
                val schedules = listOf(
                    ScheduleEntity(
                        titleEn = "Morning Phonics & Alphabet",
                        titleDari = "آموزش صبحگاهی الفبا و آواشناسی",
                        titlePashto = "د سهار الفبا او اواز پوهنه",
                        skillTarget = "Phonics",
                        hour = 7,
                        minute = 0,
                        isEnabled = true,
                        daysLabel = "Everyday"
                    ),
                    ScheduleEntity(
                        titleEn = "Midday Vocabulary Mastery",
                        titleDari = "تقویت دایره لغات و حافظه",
                        titlePashto = "د غرمې لغتونو پیاوړتیا",
                        skillTarget = "Vocabulary",
                        hour = 12,
                        minute = 30,
                        isEnabled = true,
                        daysLabel = "Everyday"
                    ),
                    ScheduleEntity(
                        titleEn = "Afternoon Conversation with Zahra",
                        titleDari = "مکالمه و گفتگوی صوتی با زهرا",
                        titlePashto = "له زهرا سره د مازیګر خبرې اترې",
                        skillTarget = "Speaking",
                        hour = 16,
                        minute = 45,
                        isEnabled = true,
                        daysLabel = "Everyday"
                    ),
                    ScheduleEntity(
                        titleEn = "Evening Grammar & Review",
                        titleDari = "دستور زبان، تمرین و مرور شبانه",
                        titlePashto = "د ماښام ګرامر او بیا کتنه",
                        skillTarget = "Grammar",
                        hour = 20,
                        minute = 15,
                        isEnabled = true,
                        daysLabel = "Everyday"
                    )
                )
                for (s in schedules) {
                    database.scheduleDao().insert(s)
                }

                // Initial Baseline Assessment
                database.assessmentDao().insert(
                    AssessmentEntity(
                        estimatedLevel = "A0",
                        overallScore = 40,
                        listeningScore = 38,
                        speakingScore = 35,
                        readingScore = 45,
                        writingScore = 32,
                        grammarScore = 40,
                        vocabScore = 50,
                        pronunciationScore = 42
                    )
                )
            }
        }
    }
}
