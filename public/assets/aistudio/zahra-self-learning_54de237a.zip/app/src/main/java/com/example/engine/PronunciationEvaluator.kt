package com.example.engine

import com.example.data.model.PronunciationResult
import kotlin.math.max
import kotlin.math.min

object PronunciationEvaluator {

    fun evaluate(expected: String, spoken: String): PronunciationResult {
        val cleanExpected = expected.trim().lowercase().replace(Regex("[^a-z0-9\\s]"), "")
        val cleanSpoken = spoken.trim().lowercase().replace(Regex("[^a-z0-9\\s]"), "")

        if (cleanSpoken.isEmpty()) {
            return PronunciationResult(
                expectedText = expected,
                spokenText = "No voice detected",
                score = 0,
                accuracy = "Needs Attempt",
                feedbackEn = "Please try speaking clearly into the microphone.",
                feedbackDari = "لطفاً با صدای واضح در مایکروفون صحبت کنید.",
                feedbackPashto = "مهرباني وکړئ په مایکروفون کې په روښانه غږ خبرې وکړئ."
            )
        }

        val distance = computeLevenshteinDistance(cleanExpected, cleanSpoken)
        val maxLength = max(cleanExpected.length, cleanSpoken.length)
        val charSimilarity = if (maxLength > 0) ((1.0 - (distance.toDouble() / maxLength)) * 100).toInt() else 100

        // Word-level token match with fuzzy similarity
        val expTokens = cleanExpected.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val spokenTokens = cleanSpoken.split(Regex("\\s+")).filter { it.isNotEmpty() }
        var tokenScoreSum = 0.0
        for (token in expTokens) {
            var bestTokenSim = 0.0
            for (spokenToken in spokenTokens) {
                val dist = computeLevenshteinDistance(token, spokenToken)
                val maxLen = max(token.length, spokenToken.length)
                val sim = if (maxLen > 0) (1.0 - (dist.toDouble() / maxLen)) else 1.0
                if (sim > bestTokenSim) {
                    bestTokenSim = sim
                }
            }
            tokenScoreSum += bestTokenSim
        }
        val tokenSimilarity = if (expTokens.isNotEmpty()) ((tokenScoreSum / expTokens.size) * 100).toInt() else 100

        val finalScore = ((charSimilarity * 0.4) + (tokenSimilarity * 0.6)).toInt().coerceIn(0, 100)

        val (accuracy, fbEn, fbDari, fbPashto) = when {
            finalScore >= 90 -> Quadruple(
                "Excellent (عالی)",
                "Exceptional clarity, rhythm, and accurate phoneme articulation!",
                "بسیار عالی! تلفظ، آهنگ صدا و وضوح کلمات فوق‌العاده دقیق بود.",
                "ډیر عالي! تلفظ، د غږ ریتم او د کلمو روښانتیا خورا دقیقه وه."
            )
            finalScore >= 75 -> Quadruple(
                "Very Good (بسیار خوب)",
                "Good natural pronunciation. A tiny adjustment in vowel stress will make it native!",
                "بسیار خوب! تلفظ طبیعی است؛ با کمی دقت روی تکیه واکه‌ها بی‌نقص خواهد شد.",
                "ډیر ښه! تلفظ طبیعي دی؛ د واول په تکیه لږ تمرکز به یې لا ښکلی کړي."
            )
            finalScore >= 50 -> Quadruple(
                "Keep Practicing (نیاز به تمرین)",
                "Understood, but slow down and listen carefully to Zahra's syllable stress.",
                "قابل فهم است، اما سرعت گفتار را کم کرده و به کشش صداها با دقت گوش دهید.",
                "د پوهیدو وړ دی، خو سرعت لږ ورو کړئ او د غږ کشولو ته پام وکړئ."
            )
            else -> Quadruple(
                "Needs Improvement (تلاش دوباره)",
                "Let's practice again together. Listen to the slow audio and repeat word by word.",
                "بیا با هم دوباره تمرین کنیم. تلفظ آهسته را بشنوید و واژه به واژه تکرار نمایید.",
                "راځئ یو ځل بیا یوځای هڅه وکړو. ورو تلفظ واورئ او کلمه په کلمه تکرار کړئ."
            )
        }

        return PronunciationResult(
            expectedText = expected,
            spokenText = spoken,
            score = finalScore,
            accuracy = accuracy,
            feedbackEn = fbEn,
            feedbackDari = fbDari,
            feedbackPashto = fbPashto
        )
    }

    private fun computeLevenshteinDistance(s1: String, s2: String): Int {
        val dp = Array(s1.length + 1) { IntArray(s2.length + 1) }
        for (i in 0..s1.length) dp[i][0] = i
        for (j in 0..s2.length) dp[0][j] = j

        for (i in 1..s1.length) {
            for (j in 1..s2.length) {
                val cost = if (s1[i - 1] == s2[j - 1]) 0 else 1
                dp[i][j] = min(
                    min(dp[i - 1][j] + 1, dp[i][j - 1] + 1),
                    dp[i - 1][j - 1] + cost
                )
            }
        }
        return dp[s1.length][s2.length]
    }

    private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)
}
