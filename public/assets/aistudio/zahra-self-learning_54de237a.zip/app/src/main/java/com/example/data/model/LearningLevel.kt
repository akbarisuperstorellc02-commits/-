package com.example.data.model

import com.example.localization.Language

enum class LearningLevel(
    val code: String,
    val titleEn: String,
    val titleDari: String,
    val titlePashto: String,
    val descriptionEn: String,
    val descriptionDari: String,
    val descriptionPashto: String,
    val order: Int
) {
    A0(
        "A0",
        "Absolute Beginner",
        "شروع از صفر مطلق",
        "له مطلق صفر څخه پیل",
        "26 letters, phonics sounds, vowels, consonants, numbers, first 50 words & basic greetings",
        "شناخت ۲۶ حرف، آواشناسی صوتی، واکه‌ها، همخوان‌ها، اعداد، اولین ۵۰ واژه و سلام و احوالپرسی",
        "د ۲۶ تورو پیژندنه، د اوازونو پوهنه، واول او کنسوننټ، شمیرې، لومړني ۵۰ لغتونه او روغبړ",
        0
    ),
    PRE_A1(
        "Pre-A1",
        "Foundation English",
        "پایه‌ریزی مکالمه و جمله‌سازی",
        "د جملو او خبرو بنسټ",
        "Basic phonetic patterns, essential sentence structures, everyday objects, simple questions",
        "الگوهای صوتی بنیادین، ساختار جملات کوتاه، پرسش‌های ابتدایی و شناخت وسایل روزمره",
        "بنسټیز غږیز الګوګانې، لنډې جملې، ساده پوښتنې او د ورځني شیانو پیژندنه",
        1
    ),
    A1(
        "A1",
        "Beginner",
        "مبتدی و زندگی روزمره",
        "پیل کوونکی او ورځنی ژوند",
        "Self-introduction, family, daily routines, time & dates, elementary verbs & pronouns",
        "معرفی خود، اعضای فامیل، کارهای روزانه، اوقات و تقویم، افعال اولیه و ضمایر شخصی",
        "ځان پیژندنه، کورنۍ، ورځني کارونه، وخت او نیټې، لومړني فعلونه او ضمیرونه",
        2
    ),
    A2(
        "A2",
        "Elementary",
        "مکالمات کاربردی و سفر",
        "عملي خبرې او سفر",
        "Past and future tenses, shopping, travel, restaurants, directions, short paragraphs",
        "زمان‌های گذشته و آینده، خرید و بازار، سفر و رستورانت، آدرس‌دهی و نگارش پاراگراف کوتاه",
        "تیر او راتلونکی زمان، پېرودل او بازار، سفر او رستورانت، لارښوونې او لنډې لیکنې",
        3
    ),
    B1(
        "B1",
        "Intermediate",
        "استقلال در مکالمه و نظردهی",
        "په خبرو کې خپلواکي",
        "Expressing opinions, storytelling, phrasal verbs, present perfect, everyday autonomy",
        "بیان نظریات، قصه‌گویی، افعال عبارتی، زمان حال کامل و استقلال کامل در ارتباطات روزمره",
        "د نظرونو بیان، کیسه ویل، مرکب فعلونه، او په ورځنیو اړیکو کې بشپړه خپلواکي",
        4
    ),
    B2(
        "B2",
        "Upper Intermediate",
        "تسلط و گرامر پیشرفته",
        "لوړ منځنی او پرمختللی ګرامر",
        "Natural discussions, passive voice, all conditionals, advanced vocabulary, essay writing",
        "بحث‌های طبیعی، مجهول، تمام شرطی‌ها، لغات پیشرفته و مهارت نوشتن مقالات منظم",
        "طبیعي بحثونه، مجهول جملې، شرطیه جوړښتونه، پرمختللي لغتونه او مقالې لیکل",
        5
    ),
    C1(
        "C1",
        "Advanced",
        "ارتباط حرفه‌ای و دانشگاهی",
        "مسلکي او پوهنتوني اړیکې",
        "Complex nuances, idiomatic expressions, academic analysis, formal speech & debate",
        "درک ظرافت‌های معنایی، اصطلاحات عمیق، تحلیل متون آکادمیک، سخنرانی و مناظره رسمی",
        "د ژورو معناګانو پوهیدل، محاوروي اصطلاحات، علمي تحلیل او مسلکي ویناوالۍ",
        6
    ),
    C2(
        "C2",
        "Proficiency Mastery",
        "تسلط کامل در سطح بومی",
        "د اصلي ویونکي په کچه بشپړ تسلط",
        "Native-level fluency, rapid complex comprehension, literary analysis & rhetoric",
        "روانی گفتار در حد زبان مادری، درک متون بسیار پیچیده، تحلیل ادبی و بلاغت پیشرفته",
        "د مورنۍ ژبې په څیر روانې خبرې، د پېچلو متونو درک او لوړه ادبي پوهه",
        7
    ),
    POST_C2(
        "Post-C2",
        "Expert Specialization",
        "تخصص‌های عالی فراتر از مرزها",
        "لوړې تخصصي څانګې",
        "Academic Publishing, Executive Business, Medical English, Legal Jurisprudence, Tech & AI",
        "انگلیسی تخصصی علمی-پژوهشی، حقوقی، تجارت بین‌الملل، طبابت، مهندسی هوش مصنوعی و ترجمه",
        "علمي څیړنې، نړیوال تجارت، طبابت، حقوق، د مصنوعي هوښ انجنیري او مسلکي ژباړه",
        8
    );

    fun localizedTitle(lang: Language): String = when (lang) {
        Language.DARI -> titleDari
        Language.PASHTO -> titlePashto
        Language.ENGLISH -> titleEn
    }

    fun localizedDesc(lang: Language): String = when (lang) {
        Language.DARI -> descriptionDari
        Language.PASHTO -> descriptionPashto
        Language.ENGLISH -> descriptionEn
    }
}
