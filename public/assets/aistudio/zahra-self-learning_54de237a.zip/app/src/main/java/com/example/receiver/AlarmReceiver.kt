package com.example.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppDatabase
import com.example.localization.Language
import com.example.localization.Strings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val scheduleId = intent.getLongExtra(AlarmScheduler.EXTRA_SCHEDULE_ID, -1L)
        val action = intent.getStringExtra(AlarmScheduler.EXTRA_ACTION)

        if (action == "ACTION_SNOOZE_5") {
            AlarmScheduler.snooze(context, scheduleId, 5)
            dismissNotification(context, scheduleId.toInt())
            return
        }
        if (action == "ACTION_SNOOZE_10") {
            AlarmScheduler.snooze(context, scheduleId, 10)
            dismissNotification(context, scheduleId.toInt())
            return
        }
        if (action == "ACTION_DISMISS") {
            dismissNotification(context, scheduleId.toInt())
            return
        }

        val title = intent.getStringExtra(AlarmScheduler.EXTRA_TITLE) ?: "English Study Session"
        val skill = intent.getStringExtra(AlarmScheduler.EXTRA_SKILL) ?: "Speaking"

        // Fetch user's language from DB asynchronously to show personalized reminder
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(context, CoroutineScope(Dispatchers.IO))
                val profile = db.userDao().getUserProfile().firstOrNull()
                val lang = Language.fromCode(profile?.selectedLanguageCode ?: "fa-AF")

                showReminderNotification(context, scheduleId, title, skill, lang)
                vibrateDevice(context)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun showReminderNotification(
        context: Context,
        scheduleId: Long,
        title: String,
        skill: String,
        lang: Language
    ) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        val channelId = "zahra_study_reminders"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Zahra Study Reminders",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Daily alarms and gentle voice reminders from Teacher Zahra"
                enableVibration(true)
                val alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                val audioAttributes = AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .build()
                setSound(alarmSound, audioAttributes)
            }
            notificationManager.createNotificationChannel(channel)
        }

        // Open App Intent
        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("OPEN_SCREEN", "TEACHER_CHAT")
            putExtra("SCHEDULE_ID", scheduleId)
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            scheduleId.toInt(),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Snooze 5 Intent
        val snooze5Intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_SCHEDULE_ID, scheduleId)
            putExtra(AlarmScheduler.EXTRA_ACTION, "ACTION_SNOOZE_5")
        }
        val snooze5PendingIntent = PendingIntent.getBroadcast(
            context,
            scheduleId.toInt() + 500,
            snooze5Intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Snooze 10 Intent
        val snooze10Intent = Intent(context, AlarmReceiver::class.java).apply {
            putExtra(AlarmScheduler.EXTRA_SCHEDULE_ID, scheduleId)
            putExtra(AlarmScheduler.EXTRA_ACTION, "ACTION_SNOOZE_10")
        }
        val snooze10PendingIntent = PendingIntent.getBroadcast(
            context,
            scheduleId.toInt() + 1000,
            snooze10Intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val voiceMessage = Strings.reminderVoiceMessage(lang)
        val notifTitle = Strings.reminderNotificationTitle(lang)

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_launcher_zahra)
            .setContentTitle(notifTitle)
            .setContentText(voiceMessage)
            .setStyle(NotificationCompat.BigTextStyle().bigText("$voiceMessage\n\n🎯 Session: $title ($skill)"))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openPendingIntent)
            .addAction(R.drawable.ic_launcher_zahra, Strings.reminderActionStart(lang), openPendingIntent)
            .addAction(0, Strings.reminderActionSnooze5(lang), snooze5PendingIntent)
            .addAction(0, Strings.reminderActionSnooze10(lang), snooze10PendingIntent)
            .build()

        notificationManager.notify(scheduleId.toInt(), notification)
    }

    private fun dismissNotification(context: Context, notificationId: Int) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        notificationManager?.cancel(notificationId)
    }

    private fun vibrateDevice(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    android.os.VibrationEffect.createWaveform(longArrayOf(0, 400, 200, 400), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                @Suppress("DEPRECATION")
                vibrator?.vibrate(longArrayOf(0, 400, 200, 400), -1)
            }
        } catch (_: Exception) {}
    }
}
