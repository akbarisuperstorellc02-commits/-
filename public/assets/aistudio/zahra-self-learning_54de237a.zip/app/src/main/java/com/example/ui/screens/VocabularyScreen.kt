package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LearningLevel
import com.example.data.model.VocabularyWord
import com.example.localization.Language
import com.example.localization.Strings
import com.example.ui.MainViewModel
import com.example.ui.components.GoldButton
import com.example.ui.components.PopcornCircleButton
import com.example.ui.components.LevelBadge
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

@Composable
fun VocabularyScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val allWords = viewModel.allVocabList
    val selectedIndex by viewModel.selectedVocabIndex.collectAsState()
    val currentWord = allWords[selectedIndex]

    var selectedLevelFilter by remember { mutableStateOf<LearningLevel?>(null) }
    var isFlipped by remember { mutableStateOf(false) }

    val filteredWords = remember(selectedLevelFilter) {
        if (selectedLevelFilter == null) allWords else allWords.filter { it.level == selectedLevelFilter }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Level Filter Bar with 3D Popcorn Tabs
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    com.example.ui.components.PopcornPillTab(
                        title = "All Levels",
                        badge = null,
                        isSelected = selectedLevelFilter == null,
                        onClick = { selectedLevelFilter = null }
                    )
                }
                items(LearningLevel.entries) { level ->
                    com.example.ui.components.PopcornPillTab(
                        title = level.code,
                        badge = null,
                        isSelected = selectedLevelFilter == level,
                        onClick = { selectedLevelFilter = level }
                    )
                }
            }
        }

        // Active Vocabulary 3D Card
        item {
            LuxuryGlassCard(
                modifier = Modifier.testTag("vocab_flashcard"),
                borderColor = LuxuryGold
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LevelBadge(levelCode = currentWord.level.code)

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PopcornCircleButton(
                            icon = Icons.Default.VolumeUp,
                            contentDescription = "Listen to word",
                            onClick = { viewModel.speak(currentWord.word) },
                            size = 46.dp
                        )

                        PopcornCircleButton(
                            icon = Icons.Default.Speed,
                            contentDescription = "Listen slow",
                            onClick = { viewModel.speak(currentWord.word, isSlow = true) },
                            size = 46.dp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Word & Phonetics
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = currentWord.word,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 32.sp,
                        color = LuxuryGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${currentWord.ipa} • ${currentWord.partOfSpeech}",
                        fontSize = 15.sp,
                        color = SoftGold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Flip Card Button
                Button(
                    onClick = { isFlipped = !isFlipped },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GlowGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isFlipped) "پنهان کردن معانی (Hide Meaning)" else "نمایش معانی دری و پشتو (Reveal Meaning)",
                        color = SoftGold,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (isFlipped) {
                    Spacer(modifier = Modifier.height(14.dp))

                    // Translations
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(DarkSurfaceElevated)
                            .padding(14.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "دری (افغانستان): ${currentWord.defDari}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "پښتو (افغانستان): ${currentWord.defPashto}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "English Def: ${currentWord.defEn}",
                                fontSize = 13.5.sp,
                                color = SoftGold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Example Sentence in Context
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(LuxuryGold.copy(alpha = 0.08f))
                            .border(1.dp, LuxuryGold.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "جمله نمونه (Example):",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = LuxuryGold
                                )
                                IconButton(
                                    onClick = { viewModel.speak(currentWord.exampleEn) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = "Speak sentence",
                                        tint = LuxuryGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "“${currentWord.exampleEn}”",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "دری: ${currentWord.exampleDari}",
                                fontSize = 13.sp,
                                color = SoftGold
                            )
                            Text(
                                text = "پښتو: ${currentWord.examplePashto}",
                                fontSize = 13.sp,
                                color = SoftGold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Collocation & Pitfall
                    Text(
                        text = "ترکیب رایج (Collocation): ${currentWord.collocation}",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "اشتباه متداول: ${currentWord.commonMistake}",
                        fontSize = 12.5.sp,
                        color = CrimsonRed
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Spaced Repetition (SRS) Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.recordVocabReview(currentWord.id, isKnown = false)
                            if (selectedIndex < allWords.size - 1) {
                                viewModel.selectVocab(selectedIndex + 1)
                                isFlipped = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CrimsonRed.copy(alpha = 0.2f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRed),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, tint = CrimsonRed)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("نیاز به مرور", color = CrimsonRed, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = {
                            viewModel.recordVocabReview(currentWord.id, isKnown = true)
                            if (selectedIndex < allWords.size - 1) {
                                viewModel.selectVocab(selectedIndex + 1)
                                isFlipped = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = ObsidianBlack)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("یاد گرفتم (Mastered)", color = ObsidianBlack, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Bottom Navigation Next / Prev Word with Popcorn 3D buttons
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                com.example.ui.components.GoldButton(
                    text = Strings.btnPrevious(lang),
                    icon = Icons.Default.ArrowBack,
                    onClick = {
                        viewModel.selectVocab(selectedIndex - 1)
                        isFlipped = false
                    },
                    enabled = selectedIndex > 0,
                    modifier = Modifier.weight(1f)
                )

                com.example.ui.components.GoldButton(
                    text = Strings.btnNext(lang),
                    icon = Icons.Default.ArrowForward,
                    onClick = {
                        viewModel.selectVocab(selectedIndex + 1)
                        isFlipped = false
                    },
                    enabled = selectedIndex < allWords.size - 1,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
private fun FilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isSelected) LuxuryGold else MaterialTheme.colorScheme.surfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) LuxuryGold else GlowGold),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 13.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) ObsidianBlack else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}
