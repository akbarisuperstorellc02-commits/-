package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "زبان‌آموز کوشا",
    val selectedLanguageCode: String = "fa-AF",
    val isDarkTheme: Boolean = true,
    val currentLevelCode: String = "A0",
    val targetGoal: String = "Mastering Fluent English",
    val streakDays: Int = 1,
    val totalStudyMinutes: Int = 25,
    val wordsLearned: Int = 18,
    val voicePitch: Float = 1.15f,
    val speechSpeed: Float = 0.95f,
    val isAccentUS: Boolean = true
)

@Entity(tableName = "study_schedules")
data class ScheduleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val titleEn: String,
    val titleDari: String,
    val titlePashto: String,
    val skillTarget: String,
    val hour: Int,
    val minute: Int,
    val isEnabled: Boolean = true,
    val daysLabel: String = "Everyday"
)

@Entity(tableName = "vocab_progress")
data class VocabProgressEntity(
    @PrimaryKey val wordId: String,
    val srsBox: Int = 1,
    val nextReviewTime: Long = System.currentTimeMillis(),
    val reviewCount: Int = 0,
    val correctCount: Int = 0
)

@Entity(tableName = "mistakes_history")
data class MistakeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // Alphabet, Grammar, Vocab, Pronunciation, Writing
    val itemPrompt: String,
    val incorrectAttempt: String,
    val correction: String,
    val explanationDari: String,
    val explanationPashto: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "assessment_records")
data class AssessmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val estimatedLevel: String,
    val overallScore: Int,
    val listeningScore: Int,
    val speakingScore: Int,
    val readingScore: Int,
    val writingScore: Int,
    val grammarScore: Int,
    val vocabScore: Int,
    val pronunciationScore: Int
)
