package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Language
import com.example.localization.Strings
import com.example.ui.MainViewModel
import com.example.ui.components.LevelBadge
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

@Composable
fun GrammarScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val lessons = viewModel.grammarLessons
    val selectedIndex by viewModel.selectedGrammarIndex.collectAsState()
    val currentLesson = lessons[selectedIndex]

    var selectedQuizOption by remember(selectedIndex) { mutableStateOf<Int?>(null) }
    var quizSubmitted by remember(selectedIndex) { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Horizontal Lesson Selector
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                itemsIndexed(lessons) { index, lesson ->
                    val isSelected = index == selectedIndex
                    com.example.ui.components.PopcornPillTab(
                        title = lesson.titleEn,
                        badge = lesson.level.code,
                        isSelected = isSelected,
                        onClick = {
                            viewModel.selectGrammar(index)
                            selectedQuizOption = null
                            quizSubmitted = false
                        }
                    )
                }
            }
        }

        // Active Lesson Card
        item {
            LuxuryGlassCard(
                modifier = Modifier.testTag("grammar_lesson_card"),
                borderColor = LuxuryGold
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LevelBadge(levelCode = currentLesson.level.code)
                    Text(
                        text = "درس شماره ${selectedIndex + 1}",
                        style = MaterialTheme.typography.labelMedium.copy(color = SoftGold)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = currentLesson.titleEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    color = LuxuryGold
                )

                val subTitle = when (lang) {
                    Language.DARI -> currentLesson.titleDari
                    Language.PASHTO -> currentLesson.titlePashto
                    Language.ENGLISH -> ""
                }
                if (subTitle.isNotEmpty()) {
                    Text(
                        text = subTitle,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Formula / Pattern Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(LuxuryGold.copy(alpha = 0.1f))
                        .border(1.dp, LuxuryGold.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(
                            text = "ساختار و فرمول گرامری (Grammar Pattern):",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = LuxuryGold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = currentLesson.formula,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = SoftGold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Explanation in selected UI language
                val explanation = when (lang) {
                    Language.DARI -> currentLesson.explanationDari
                    Language.PASHTO -> currentLesson.explanationPashto
                    Language.ENGLISH -> currentLesson.explanationEn
                }
                Text(
                    text = explanation,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 22.sp
                )
            }
        }

        // Illustrative Examples Card
        item {
            LuxuryGlassCard(borderColor = GlowGold) {
                Text(
                    text = "مثال‌های کاربردی (Examples in Context):",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = LuxuryGold
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    currentLesson.examples.forEach { example ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkSurfaceElevated)
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = example.english,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (lang == Language.PASHTO) example.pashto else example.dari,
                                        fontSize = 13.sp,
                                        color = SoftGold
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.speak(example.english) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VolumeUp,
                                        contentDescription = "Speak example",
                                        tint = LuxuryGold,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Interactive Practice Quiz
        if (currentLesson.quiz.isNotEmpty()) {
            val q = currentLesson.quiz[0]
            item {
                LuxuryGlassCard(borderColor = WarmGold.copy(alpha = 0.5f)) {
                    Text(
                        text = "تمرین و سنجش یادگیری (Interactive Practice):",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = LuxuryGold
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = q.question,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Options List with tactile Popcorn cards
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        q.options.forEachIndexed { idx, option ->
                            val isSelected = selectedQuizOption == idx
                            val isCorrect = idx == q.correctIndex
                            val optionState = when {
                                quizSubmitted && isCorrect -> true
                                quizSubmitted && isSelected && !isCorrect -> false
                                else -> null
                            }

                            com.example.ui.components.PopcornSelectableOption(
                                text = option,
                                isSelected = isSelected,
                                prefixNumber = idx + 1,
                                isCorrect = optionState,
                                enabled = !quizSubmitted,
                                onClick = {
                                    selectedQuizOption = idx
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    if (!quizSubmitted) {
                        com.example.ui.components.GoldButton(
                            text = Strings.btnSubmit(lang),
                            onClick = {
                                if (selectedQuizOption != null) {
                                    quizSubmitted = true
                                    val isCorrect = selectedQuizOption == q.correctIndex
                                    viewModel.recordQuizAnswer(
                                        lessonId = currentLesson.id,
                                        isCorrect = isCorrect,
                                        questionText = q.question,
                                        userAnswer = q.options[selectedQuizOption!!],
                                        correctAnswer = q.options[q.correctIndex],
                                        explanationDari = q.explanationDari,
                                        explanationPashto = q.explanationPashto
                                    )
                                }
                            },
                            enabled = selectedQuizOption != null,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        // Explanation of Answer
                        val explanationMsg = when (lang) {
                            Language.DARI -> q.explanationDari
                            Language.PASHTO -> q.explanationPashto
                            Language.ENGLISH -> q.explanationEn
                        }
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(DarkSurfaceElevated)
                                .padding(12.dp)
                        ) {
                            Column {
                                Text(
                                    text = if (selectedQuizOption == q.correctIndex) "آفرین! پاسخ شما صحیح است." else "توضیح پاسخ صحیح:",
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedQuizOption == q.correctIndex) EmeraldGreen else LuxuryGold,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = explanationMsg,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
