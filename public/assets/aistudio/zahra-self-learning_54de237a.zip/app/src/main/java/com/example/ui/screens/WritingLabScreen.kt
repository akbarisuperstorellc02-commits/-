package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Create
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.Language
import com.example.localization.Strings
import com.example.ui.MainViewModel
import com.example.ui.components.GoldButton
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

@Composable
fun WritingLabScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val writingCorrection by viewModel.writingCorrection.collectAsState()

    var userDraft by remember {
        mutableStateOf("hello my name is ali and i am agree with zahra. he go to work in the night and don't have no fear")
    }

    val samplePrompts = listOf(
        "Introduce yourself and your life goals in English.",
        "Describe your daily routine from morning until evening.",
        "Why is learning English essential for modern careers?",
        "Describe a memorable journey through Afghanistan."
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Header & Quick Prompt selector
        item {
            LuxuryGlassCard(
                modifier = Modifier.testTag("writing_header_card"),
                borderColor = LuxuryGold
            ) {
                Text(
                    text = Strings.sectionWritingLab(lang),
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = LuxuryGold
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "متن یا انشای خود را به انگلیسی بنویسید تا موتور هوش مصنوعی زهرا آن را از نظر گرامر، املا، نشانه‌گذاری و روان‌بودن تصحیح کند.",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "موضوعات پیشنهادی (Sample Prompts):",
                    style = MaterialTheme.typography.labelSmall.copy(color = SoftGold)
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(samplePrompts) { prompt ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = DarkSurfaceElevated,
                            border = androidx.compose.foundation.BorderStroke(1.dp, GlowGold),
                            modifier = Modifier.clickable {
                                userDraft = ""
                            }
                        ) {
                            Text(
                                text = prompt,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Text Input Workbench
        item {
            LuxuryGlassCard(borderColor = GlowGold) {
                Text(
                    text = "پیش‌نویس شما (Your English Composition):",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = userDraft,
                    onValueChange = { userDraft = it },
                    placeholder = { Text("Write your English text here...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(160.dp)
                        .testTag("writing_input_field"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = LuxuryGold,
                        unfocusedBorderColor = DarkBorder,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    ),
                    maxLines = 10
                )

                Spacer(modifier = Modifier.height(14.dp))

                GoldButton(
                    text = "بررسی و تصحیح هوشمند متن (Analyze & Polish)",
                    icon = Icons.Default.AutoFixHigh,
                    onClick = {
                        viewModel.analyzeUserWriting(userDraft)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_analyze_writing"
                )
            }
        }

        // Correction & Evaluation Results
        if (writingCorrection != null) {
            val c = writingCorrection!!
            item {
                LuxuryGlassCard(
                    modifier = Modifier.testTag("writing_results_card"),
                    borderColor = if (c.issuesFound.isEmpty()) EmeraldGreen else LuxuryGold
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "نمره نگارش: ${c.score}٪",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp,
                            color = if (c.score >= 80) EmeraldGreen else LuxuryGold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = EmeraldGreen.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "Grammar: ${c.grammarScore}٪",
                                    fontSize = 11.sp,
                                    color = EmeraldGreen,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = ChampagneGold.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "Vocab: ${c.vocabScore}٪",
                                    fontSize = 11.sp,
                                    color = ChampagneGold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Corrected Natural Version
                    Text(
                        text = "نسخه ویرایش‌شده و استاندارد (Polished Version):",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = LuxuryGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkSurfaceElevated)
                            .border(1.dp, EmeraldGreen.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Text(
                            text = c.correctedText,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 14.5.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 22.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Detailed Issue Breakdown
                    if (c.issuesFound.isNotEmpty()) {
                        Text(
                            text = "نکات و اصلاحات گرامری (${c.issuesFound.size} مورد):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            c.issuesFound.forEachIndexed { idx, issue ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(DarkSurfaceElevated)
                                        .padding(12.dp)
                                ) {
                                    Column {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "${idx + 1}. ${issue.ruleType}",
                                                fontWeight = FontWeight.Bold,
                                                color = CrimsonRed,
                                                fontSize = 13.sp
                                            )
                                            Text(
                                                text = "«${issue.snippet}» ➔ «${issue.correction}»",
                                                fontWeight = FontWeight.Bold,
                                                color = EmeraldGreen,
                                                fontSize = 13.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(4.dp))
                                        val reason = if (lang == Language.PASHTO) issue.reasonPashto else issue.reasonDari
                                        Text(
                                            text = reason,
                                            fontSize = 12.5.sp,
                                            color = SoftGold,
                                            lineHeight = 18.sp
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(EmeraldGreen.copy(alpha = 0.1f))
                                .padding(12.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldGreen)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "تبریک! هیچ خطای گرامری یا ساختاری در این متن یافت نشد.",
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldGreen,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
