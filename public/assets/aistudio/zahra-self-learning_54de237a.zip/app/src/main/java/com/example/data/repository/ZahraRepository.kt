package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.AssessmentEntity
import com.example.data.local.MistakeEntity
import com.example.data.local.ScheduleEntity
import com.example.data.local.UserProfileEntity
import com.example.data.local.VocabProgressEntity
import kotlinx.coroutines.flow.Flow

class ZahraRepository(private val database: AppDatabase) {

    val userProfile: Flow<UserProfileEntity?> = database.userDao().getUserProfile()
    val allSchedules: Flow<List<ScheduleEntity>> = database.scheduleDao().getAllSchedules()
    val allVocabProgress: Flow<List<VocabProgressEntity>> = database.vocabDao().getAllProgress()
    val masteredWordsCount: Flow<Int> = database.vocabDao().getMasteredWordsCount()
    val allMistakes: Flow<List<MistakeEntity>> = database.mistakeDao().getAllMistakes()
    val latestAssessment: Flow<AssessmentEntity?> = database.assessmentDao().getLatestAssessment()

    suspend fun saveProfile(profile: UserProfileEntity) {
        database.userDao().insertOrUpdate(profile)
    }

    suspend fun saveSchedule(schedule: ScheduleEntity): Long {
        return database.scheduleDao().insert(schedule)
    }

    suspend fun updateSchedule(schedule: ScheduleEntity) {
        database.scheduleDao().update(schedule)
    }

    suspend fun deleteSchedule(scheduleId: Long) {
        database.scheduleDao().deleteById(scheduleId)
    }

    suspend fun recordMistake(mistake: MistakeEntity) {
        database.mistakeDao().insert(mistake)
    }

    suspend fun clearMistakes() {
        database.mistakeDao().clearAll()
    }

    suspend fun advanceVocabSrs(wordId: String, isCorrect: Boolean) {
        val progress = VocabProgressEntity(
            wordId = wordId,
            srsBox = if (isCorrect) 3 else 1,
            nextReviewTime = System.currentTimeMillis() + if (isCorrect) 86400000L * 3 else 3600000L,
            reviewCount = 1,
            correctCount = if (isCorrect) 1 else 0
        )
        database.vocabDao().insertOrUpdate(progress)
    }

    suspend fun recordAssessment(assessment: AssessmentEntity) {
        database.assessmentDao().insert(assessment)
    }
}
