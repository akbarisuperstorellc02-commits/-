package com.example.data.curriculum

import com.example.data.model.GradedStory
import com.example.data.model.LearningLevel

object StoriesData {
    val stories: List<GradedStory> = listOf(
        GradedStory(
            id = "story_a0_1",
            level = LearningLevel.A0,
            titleEn = "Zahra and the Golden Sun",
            titleDari = "زهرا و آفتاب زرین",
            titlePashto = "زهرا او زرین لمر",
            fullTextEn = "The sun is up. It is warm and bright. Zahra opens the big door. She sees a lovely green tree. A little bird sings on the branch. Zahra says: 'Good morning, sweet bird!' She holds a pen and an open book. Today is a happy day to learn.",
            fullTextDari = "آفتاب برآمده است. هوا گرم و روشن است. زهرا دروازه بزرگ را باز می‌کند. او یک درخت زیبای سبز را می‌بیند. یک پرنده کوچک روی شاخه آواز می‌خواند. زهرا می‌گوید: «صبح بخیر، پرنده قشنگ!» او یک قلم و یک کتاب باز در دست دارد. امروز روزی شاد برای یادگیری است.",
            fullTextPashto = "لمر راختلی دی. هوا ګرمه او روښانه ده. زهرا لویه دروازه پرانیزي. هغه یوه ښکلې شنه ونه ګوري. یو کوچنی مرغۍ په څانګه سندره بولي. زهرا وايي: 'سهار پخیر، ښکلې مرغۍ!' هغه په لاس کې یو قلم او خلاص کتاب لري. نن د زده کړې لپاره یوه خوشاله ورځ ده.",
            keyWords = listOf("Sun", "Warm", "Door", "Tree", "Bird", "Book"),
            comprehensionQuestion = "What does Zahra hold in her hand?",
            options = listOf("An apple", "A pen and an open book", "A cup of tea", "A key"),
            correctOptionIndex = 1
        ),
        GradedStory(
            id = "story_a1_1",
            level = LearningLevel.A1,
            titleEn = "The Secret of the Mountain Library",
            titleDari = "راز کتابخانه کوهستان",
            titlePashto = "د غره د کتابتون راز",
            fullTextEn = "High in the peaceful Hindu Kush mountains, there was a hidden library full of ancient knowledge. Every day, young students walked up the quiet path. They loved the smell of old paper and the soft warmth of the fireplace. An elderly scholar said: 'Knowledge is a light that never goes dark.' The students read until sunset, filling their hearts with wonder.",
            fullTextDari = "در بلندای کوه‌های آرام هندوکش، کتابخانه‌ای پنهان پر از دانش کهن وجود داشت. هر روز دانش‌آموزان جوان از راه خاموش بالا می‌رفتند. آنها بوی کاغذهای قدیمی و گرمای ملایم بخاری را دوست داشتند. دانشمند سالخورده گفت: «دانش نوری است که هرگز تاریک نمی‌شود.» دانش‌آموزان تا غروب آفتاب مطالعه می‌کردند و دل‌هایشان از شگفتی لبریز می‌شد.",
            fullTextPashto = "د هندوکش د غرونو په لوړو کې، یو پټ کتابتون و چې له پخوانیو علمونو ډک و. هره ورځ ځوانو زده کوونکو په ارامه لاره پورته تګ کاوه. دوی د زړو پاڼو بوی او د بخاری نرمه تودوخه خوښوله. یو مشر عالم وویل: 'پوهه هغه رڼا ده چې هیڅکله نه مړ کیږي.' زده کوونکو تر لمر لویدو پورې کتابونه لوستل.",
            keyWords = listOf("Mountains", "Library", "Knowledge", "Scholar", "Sunset"),
            comprehensionQuestion = "Where was the hidden library located?",
            options = listOf("Beside the ocean", "In the busy city center", "In the peaceful mountains", "Under the ground"),
            correctOptionIndex = 2
        ),
        GradedStory(
            id = "story_b1_1",
            level = LearningLevel.B1,
            titleEn = "The Tapestry of Courage",
            titleDari = "تار و پود شجاعت",
            titlePashto = "د زړورتیا جال او ښکلا",
            fullTextEn = "In a vibrant workshop, a young artisan sat weaving a magnificent silk carpet. Her grandmother watched silently, observing every precise movement. 'Grandmother,' the girl confessed, 'yesterday I made a mistake with the golden thread.' The grandmother smiled warmly and replied: 'My child, in our tradition, an honest flaw woven with perseverance becomes the most admired signature of true mastery.' Inspired, the girl continued weaving with renewed confidence.",
            fullTextDari = "در یک کارگاه پرشور، دختر هنرمندی مشغول بافتن یک قالین ابریشمی شگفت‌انگیز بود. مادربزرگش خاموشانه نگاه می‌کرد و حرکات دقیق او را می‌دید. دختر گفت: «مادربزرگ، دیروز در تار زرین اشتباهی کردم.» مادربزرگ با مهربانی لبخند زد و پاسخ داد: «فرزندم، در رسم ما، نقصی صادقانه که با پشتکار بافته شود، به ستودنی‌ترین نشانه استادی واقعی تبدیل می‌شود.» دختر با الهام از این سخن، با اعتماد به نفس دوباره به کار ادامه داد.",
            fullTextPashto = "په یوه هنري کارځای کې، یوې هنرمندې نجلۍ د ورېښمو یو ښکلی غالۍ اوبدله. نیا یې په ارامه ورته کتل. نجلۍ وویل: 'نیا، پرون ما په زرین تار کې یوه تیروتنه وکړه.' نیا په مینه وخندل او ویې ویل: 'زما ماشومې، زموږ په دود کې، یوه صادقانه نیمګړتیا چې په زغم او هڅه سمه شي، د رښتیني استادۍ تر ټولو غوره نښه ده.' نجلۍ په پوره باور بیرته خپل کار ته دوام ورکړ.",
            keyWords = listOf("Artisan", "Magnificent", "Perseverance", "Mastery", "Confidence"),
            comprehensionQuestion = "What did the grandmother say about mistakes woven with perseverance?",
            options = listOf("They ruin the work", "They become the most admired signature of mastery", "They should be hidden", "They cost too much"),
            correctOptionIndex = 1
        ),
        GradedStory(
            id = "story_post_c2_1",
            level = LearningLevel.POST_C2,
            titleEn = "The Epistemology of Scientific Discovery",
            titleDari = "معرفت‌شناسی کشف علمی و پیشرفت بشری",
            titlePashto = "د علمي کشفونو معرفت او انساني پرمختګ",
            fullTextEn = "Scientific paradigms rarely shift through incremental orthodoxy; rather, transformative breakthroughs emerge when empirical anomalies dismantle prevailing theoretical dogmas. The philosopher of science Karl Popper underscored that empirical verifiability is subordinate to rigorous falsifiability. When researchers cultivate methodological skepticism while embracing interdisciplinary synthesis, they bridge abstract ontology with transformative technological innovation.",
            fullTextDari = "پارادایم‌های علمی به ندرت از طریق تکرار سنت‌های موجود دگرگون می‌شوند؛ بلکه دستاوردهای بنیادین زمانی پدیدار می‌گردند که ناهماهنگی‌های تجربی، باورهای نظری حاکم را به چالش بکشند. کارل پوپر تأکید نمود که ابطال‌پذیری دقیق بر اثبات‌گرایی تقدم دارد. هنگامی که پژوهشگران شکاکیت روش‌شناختی را همراه با پیوند میان‌رشته‌ای در پیش گیرند، هستی‌شناسی انتزاعی را به نوآوری‌های ملموس فناوری پیوند می‌زنند.",
            fullTextPashto = "علمي چوکاټونه یوازې په عادي تکرار نه بدلیږي؛ بلکې ستر علمي بدلونونه هغه وخت رامنځته کیږي چې عیني تجربې پخوانۍ نظریې ننګوي. کارل پوپر ټینګار کاوه چې د نظریاتو د باطلیدو ازمویل خورا بنسټیز دي. کله چې محققین ګډې څانګې سره یوځای کوي، دوی پوهه په نویو عملي ټیکنالوژیو بدلوي.",
            keyWords = listOf("Paradigm", "Orthodoxy", "Empirical", "Falsifiability", "Synthesis"),
            comprehensionQuestion = "According to the passage, when do transformative breakthroughs emerge?",
            options = listOf(
                "When empirical anomalies dismantle prevailing theoretical dogmas",
                "When funding is unlimited",
                "When old traditions are never questioned",
                "When computers replace human researchers"
            ),
            correctOptionIndex = 0
        )
    )
}
