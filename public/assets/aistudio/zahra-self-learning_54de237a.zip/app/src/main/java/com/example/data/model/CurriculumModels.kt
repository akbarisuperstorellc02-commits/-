package com.example.data.model

data class AlphabetLetter(
    val letter: Char,
    val lowerLetter: Char = letter.lowercaseChar(),
    val name: String,
    val phoneticSound: String,
    val ipa: String,
    val isVowel: Boolean,
    val exampleWord: String,
    val exampleIpa: String,
    val exampleDari: String,
    val examplePashto: String,
    val tipDari: String,
    val tipPashto: String
)

data class PhonicsBlend(
    val blend: String,
    val ipa: String,
    val soundDesc: String,
    val soundDescDari: String,
    val soundDescPashto: String,
    val exampleWords: List<String>
)

data class VocabularyWord(
    val id: String,
    val word: String,
    val ipa: String,
    val partOfSpeech: String,
    val defDari: String,
    val defPashto: String,
    val defEn: String,
    val exampleEn: String,
    val exampleDari: String,
    val examplePashto: String,
    val collocation: String,
    val commonMistake: String,
    val level: LearningLevel
)

data class GrammarExample(
    val english: String,
    val dari: String,
    val pashto: String
)

data class GrammarQuizQuestion(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanationDari: String,
    val explanationPashto: String,
    val explanationEn: String
)

data class GrammarLesson(
    val id: String,
    val level: LearningLevel,
    val titleEn: String,
    val titleDari: String,
    val titlePashto: String,
    val explanationEn: String,
    val explanationDari: String,
    val explanationPashto: String,
    val formula: String,
    val examples: List<GrammarExample>,
    val quiz: List<GrammarQuizQuestion>
)

data class GradedStory(
    val id: String,
    val level: LearningLevel,
    val titleEn: String,
    val titleDari: String,
    val titlePashto: String,
    val fullTextEn: String,
    val fullTextDari: String,
    val fullTextPashto: String,
    val keyWords: List<String>,
    val comprehensionQuestion: String,
    val options: List<String>,
    val correctOptionIndex: Int
)

data class ConversationScenario(
    val id: String,
    val iconName: String,
    val titleEn: String,
    val titleDari: String,
    val titlePashto: String,
    val descriptionEn: String,
    val descriptionDari: String,
    val descriptionPashto: String,
    val initialTeacherMessage: String,
    val suggestedUserResponses: List<String>
)

data class ChatMessage(
    val id: String,
    val isFromTeacher: Boolean,
    val text: String,
    val translationDari: String? = null,
    val translationPashto: String? = null,
    val audioDurationMs: Long = 0,
    val timestamp: Long = System.currentTimeMillis()
)

data class PronunciationResult(
    val expectedText: String,
    val spokenText: String,
    val score: Int, // 0 to 100
    val accuracy: String, // Excellent, Good, Needs Improvement
    val feedbackEn: String,
    val feedbackDari: String,
    val feedbackPashto: String
)

data class WritingCorrection(
    val originalText: String,
    val correctedText: String,
    val score: Int,
    val grammarScore: Int,
    val vocabScore: Int,
    val coherenceScore: Int,
    val issuesFound: List<WritingIssue>,
    val overallRemarksDari: String,
    val overallRemarksPashto: String,
    val overallRemarksEn: String
)

data class WritingIssue(
    val snippet: String,
    val correction: String,
    val ruleType: String,
    val reasonDari: String,
    val reasonPashto: String,
    val reasonEn: String
)

data class StudySessionItem(
    val id: Long = 0,
    val titleEn: String,
    val titleDari: String,
    val titlePashto: String,
    val skillTarget: String,
    val hour: Int,
    val minute: Int,
    val isEnabled: Boolean = true,
    val daysLabel: String = "Daily"
)
