package com.example.localization

enum class Language(val code: String, val titleInSelf: String, val englishName: String, val isRtl: Boolean) {
    DARI("fa-AF", "دری (افغانستان)", "Dari", true),
    PASHTO("ps-AF", "پښتو (افغانستان)", "Pashto", true),
    ENGLISH("en-US", "English (US)", "English", false);

    companion object {
        fun fromCode(code: String): Language {
            return entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: DARI
        }
    }
}
