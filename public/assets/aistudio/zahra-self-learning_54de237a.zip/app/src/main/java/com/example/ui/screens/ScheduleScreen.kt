package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ScheduleEntity
import com.example.localization.Language
import com.example.localization.Strings
import com.example.ui.MainViewModel
import com.example.ui.components.GoldButton
import com.example.ui.components.LuxuryGlassCard
import com.example.ui.theme.CrimsonRed
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.GlowGold
import com.example.ui.theme.LuxuryGold
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.SoftGold
import com.example.ui.theme.WarmGold

@Composable
fun ScheduleScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val lang by viewModel.currentLanguage.collectAsState()
    val schedules by viewModel.schedulesList.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var newTitle by remember { mutableStateOf("") }
    var newHour by remember { mutableIntStateOf(9) }
    var newMinute by remember { mutableIntStateOf(0) }
    var newSkill by remember { mutableStateOf("Speaking") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { Spacer(modifier = Modifier.height(4.dp)) }

        // Hero Exact Alarm Manager Card
        item {
            LuxuryGlassCard(
                modifier = Modifier.testTag("alarm_hero_card"),
                borderColor = LuxuryGold
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = Strings.sectionDailySchedule(lang),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = LuxuryGold
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "سیستم هوشمند زنگ و پیام صوتی زنانه؛ فعال حتی در صورت بسته بودن برنامه یا خاموش بودن صفحه گوشی.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                lineHeight = 18.sp
                            )
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(LuxuryGold.copy(alpha = 0.15f))
                            .border(1.dp, LuxuryGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Alarm,
                            contentDescription = null,
                            tint = LuxuryGold,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Voice Reminder Test Button
                GoldButton(
                    text = "آزمایش پخش زنده پیام صوتی استاد گوهری (Test Voice Alarm)",
                    icon = Icons.Default.GraphicEq,
                    onClick = { viewModel.testAlarmVoiceNow() },
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "btn_test_alarm_voice"
                )
            }
        }

        // Section Title with Add Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "برنامه جلسات روزانه (Study Timetable):",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )

                com.example.ui.components.GoldButton(
                    text = "جلسه جدید",
                    icon = Icons.Default.Add,
                    onClick = { showAddDialog = true },
                    modifier = Modifier.height(44.dp)
                )
            }
        }

        // List of Active Schedules
        items(schedules) { schedule ->
            ScheduleRowCard(
                schedule = schedule,
                lang = lang,
                onToggle = { viewModel.toggleSchedule(schedule) },
                onDelete = { viewModel.deleteSchedule(schedule.id) }
            )
        }

        // Technical Guarantee Card
        item {
            LuxuryGlassCard(borderColor = EmeraldGreen.copy(alpha = 0.4f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = EmeraldGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ویژگی‌های فنی و پایداری سیستم هشدار استاد گوهری:",
                        fontWeight = FontWeight.Bold,
                        color = EmeraldGreen,
                        fontSize = 14.sp
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "• زمان‌بندی دقیق با AlarmManager.RTC_WAKEUP\n• پخش پیام صوتی زنانه با TextToSpeech محلی بدون نیاز به اینترنت\n• قابلیت بازیابی خودکار پس از راه اندازی مجدد گوشی (BootReceiver)\n• دکمه‌های تعویق ۵ و ۱۰ دقیقه و شروع درس در اعلانات",
                    fontSize = 12.5.sp,
                    color = SoftGold,
                    lineHeight = 22.sp
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = {
                Text("افزودن زمان مطالعه جدید", color = LuxuryGold, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("عنوان جلسه (مثلاً تمرین مکالمه)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = newHour.toString(),
                            onValueChange = { it.toIntOrNull()?.let { h -> newHour = h.coerceIn(0, 23) } },
                            label = { Text("ساعت (0-23)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = newMinute.toString(),
                            onValueChange = { it.toIntOrNull()?.let { m -> newMinute = m.coerceIn(0, 59) } },
                            label = { Text("دقیقه (0-59)") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = newSkill,
                        onValueChange = { newSkill = it },
                        label = { Text("مهارت هدف (Speaking, Vocab...)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val title = if (newTitle.isBlank()) "Study Session" else newTitle
                        viewModel.addSchedule(title, title, title, newHour, newMinute, newSkill)
                        showAddDialog = false
                        newTitle = ""
                    }
                ) {
                    Text(Strings.btnSave(lang))
                }
            },
            dismissButton = {
                Button(onClick = { showAddDialog = false }) {
                    Text(Strings.btnCancel(lang))
                }
            }
        )
    }
}

@Composable
private fun ScheduleRowCard(
    schedule: ScheduleEntity,
    lang: Language,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    val timeFormatted = String.format("%02d:%02d", schedule.hour, schedule.minute)
    val title = when (lang) {
        Language.DARI -> schedule.titleDari
        Language.PASHTO -> schedule.titlePashto
        Language.ENGLISH -> schedule.titleEn
    }

    val shape = RoundedCornerShape(20.dp)

    Box(modifier = Modifier.fillMaxWidth()) {
        // 3D Extruded Bottom Shadow Lip
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .matchParentSize()
                .offset(y = 4.dp)
                .clip(shape)
                .background(if (schedule.isEnabled) com.example.ui.theme.PopcornShadow.copy(alpha = 0.7f) else DarkBorder)
        )

        Card(
            shape = shape,
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            border = androidx.compose.foundation.BorderStroke(
                1.5.dp,
                if (schedule.isEnabled) com.example.ui.theme.PopcornBorder else DarkBorder
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = timeFormatted,
                        fontWeight = FontWeight.ExtraBold,
                    fontSize = 28.sp,
                    color = if (schedule.isEnabled) LuxuryGold else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Skill: ${schedule.skillTarget} • ${schedule.daysLabel}",
                    fontSize = 12.sp,
                    color = SoftGold
                )
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = CrimsonRed.copy(alpha = 0.7f),
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Switch(
                checked = schedule.isEnabled,
                onCheckedChange = { onToggle() },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = LuxuryGold,
                    checkedTrackColor = LuxuryGold.copy(alpha = 0.3f),
                    uncheckedThumbColor = Color.Gray,
                    uncheckedTrackColor = DarkBorder
                )
            )
        }
    }
}
